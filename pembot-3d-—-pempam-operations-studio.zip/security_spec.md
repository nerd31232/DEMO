# Security Specification & Dirty Dozen Payloads

## 1. Data Invariants
1. A `UserProfile` document at `/users/{userId}` can only be read, created, or updated by the verified authenticated user whose `request.auth.uid == userId` and `data.uid == request.auth.uid`. Blanket `list` on `/users` is denied to protect PII (`email`).
2. Every `AuditRun` at `/users/{userId}/audits/{auditId}` belongs strictly to `userId` (`ownerId == request.auth.uid`). `ownerId` and `createdAt` are immutable after creation.
3. Terminal state locking: Once `AuditRun.writeLockStatus` reaches `'CONFIRMED_AND_EXPORTED'`, no further updates are permitted (immutable audit trail).
4. Every `InventoryItem` at `/users/{userId}/inventory/{itemId}` belongs strictly to `userId` (`ownerId == request.auth.uid`), with bounded numeric stock counts (`>= 0`) and strict `affectedKeys().hasOnly(...)` on update.
5. All document IDs (`userId`, `auditId`, `itemId`) must match `^[a-zA-Z0-9_\-]+$` and be `<= 128` chars.
6. All timestamps (`createdAt`, `updatedAt`) must equal `request.time`.

## 2. Dirty Dozen Payloads (Must All Return PERMISSION_DENIED)
1. **Unauthenticated read on profile**: `GET /users/userA` with `auth = null`.
2. **Cross-user profile read**: `GET /users/userB` as `userA` (`uid: 'userA', email_verified: true`).
3. **Unverified email write**: `CREATE /users/userA` as `userA` with `email_verified: false`.
4. **Shadow/Ghost field injection on profile**: `CREATE /users/userA` with valid fields + `{ "isAdmin": true }`.
5. **Identity spoofing on AuditRun**: `CREATE /users/userA/audits/audit1` with `ownerId: "userB"`.
6. **Client-forged timestamp**: `CREATE /users/userA/audits/audit1` with `createdAt: Timestamp(2020-01-01)`.
7. **Blanket collection list scraping**: `LIST /users` as `userA`.
8. **Terminal state bypass**: `UPDATE /users/userA/audits/audit1` when `existing.writeLockStatus == 'CONFIRMED_AND_EXPORTED'`.
9. **Immutable ownerId mutation**: `UPDATE /users/userA/inventory/sku1` changing `ownerId` to `"userB"`.
10. **Denial-of-Wallet oversized string**: `CREATE /users/userA/audits/audit1` with `title` of 5,000 chars (`> 160`).
11. **ID poisoning**: `CREATE /users/userA/inventory/` with `itemId` length 200 or containing `.` / `$`.
12. **Negative stock / invalid enum value poisoning**: `UPDATE /users/userA/inventory/sku1` with `status: "COMPROMISED"` or `actualStock: -50`.
