import { CalendarEventItem, PendingCalendarAction } from '../types/operations';

export async function fetchUpcomingCalendarEvents(
  accessToken: string
): Promise<CalendarEventItem[]> {
  const nowIso = new Date().toISOString();
  const url = new URL(
    'https://www.googleapis.com/calendar/v3/calendars/primary/events'
  );
  url.searchParams.set('timeMin', nowIso);
  url.searchParams.set('singleEvents', 'true');
  url.searchParams.set('orderBy', 'startTime');
  url.searchParams.set('maxResults', '12');

  const res = await fetch(url.toString(), {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Google Calendar read failed (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const items = Array.isArray(data.items) ? data.items : [];
  return items.map((ev: Record<string, any>) => ({
    id: String(ev.id || ''),
    summary: String(ev.summary || '(Untitled Event)'),
    start: String(ev.start?.dateTime || ev.start?.date || ''),
    end: String(ev.end?.dateTime || ev.end?.date || ''),
    description: ev.description ? String(ev.description) : undefined,
    location: ev.location ? String(ev.location) : undefined,
    htmlLink: ev.htmlLink ? String(ev.htmlLink) : undefined,
  }));
}

export async function createCalendarEvent(
  accessToken: string,
  payload: PendingCalendarAction
): Promise<CalendarEventItem> {
  const res = await fetch(
    'https://www.googleapis.com/calendar/v3/calendars/primary/events',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        summary: payload.summary,
        description: payload.description,
        location: payload.location,
        start: {
          dateTime: payload.startIso,
          timeZone: 'Asia/Manila',
        },
        end: {
          dateTime: payload.endIso,
          timeZone: 'Asia/Manila',
        },
      }),
    }
  );

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Google Calendar create failed (${res.status}): ${errText}`);
  }

  const ev = await res.json();
  return {
    id: String(ev.id || ''),
    summary: String(ev.summary || payload.summary),
    start: String(ev.start?.dateTime || payload.startIso),
    end: String(ev.end?.dateTime || payload.endIso),
    description: ev.description ? String(ev.description) : payload.description,
    location: ev.location ? String(ev.location) : payload.location,
    htmlLink: ev.htmlLink ? String(ev.htmlLink) : undefined,
  };
}
