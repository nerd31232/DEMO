import {
  collection,
  doc,
  getDoc,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { auth, db } from './firebase';
import {
  BotCustomizationProfile,
  InventoryHealthRow,
  OperationalAnalysisResult,
  WriteLockStatus,
} from '../types/operations';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export interface StoredAuditRun {
  id: string;
  title: string;
  sourceFormat: string;
  netRevenuePhp: number;
  errorCount: number;
  writeLockStatus: WriteLockStatus;
  summaryMarkdown: string;
  botAnimation: string;
  officeLighting: string;
  createdAt?: unknown;
}

function clampStr(val: string, max: number, fallback = 'N/A'): string {
  const trimmed = (val || fallback).trim();
  return trimmed.slice(0, max);
}

function sanitizeId(raw: string): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 80);
  return cleaned || `id-${Date.now()}`;
}

export async function loadUserProfile(
  uid: string
): Promise<BotCustomizationProfile | null> {
  const path = `users/${uid}`;
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    if (!snap.exists()) return null;
    const data = snap.data();
    return {
      botName: String(data.botName || 'PemBot 3D'),
      companyName: String(data.companyName || 'Pempam'),
      officeTheme: data.officeTheme || 'daylight_studio',
      outfitStyle: data.outfitStyle || 'standard_chassis',
      accentColor: String(data.accentColor || '#2563EB'),
      personality: data.personality || 'friendly_coworker',
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function saveUserProfile(
  uid: string,
  displayName: string,
  email: string,
  profile: BotCustomizationProfile
): Promise<void> {
  const path = `users/${uid}`;
  try {
    const ref = doc(db, 'users', uid);
    const existing = await getDoc(ref);
    const accent = /^#[0-9a-fA-F]{6}$/.test(profile.accentColor)
      ? profile.accentColor
      : '#2563EB';

    if (!existing.exists()) {
      await setDoc(ref, {
        uid,
        displayName: clampStr(displayName, 120, 'Operator'),
        email: clampStr(email, 200, 'operator@pempam.local'),
        botName: clampStr(profile.botName, 60, 'PemBot 3D'),
        companyName: clampStr(profile.companyName, 80, 'Pempam'),
        officeTheme: profile.officeTheme,
        outfitStyle: profile.outfitStyle,
        accentColor: accent,
        personality: profile.personality,
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        displayName: clampStr(displayName, 120, 'Operator'),
        botName: clampStr(profile.botName, 60, 'PemBot 3D'),
        companyName: clampStr(profile.companyName, 80, 'Pempam'),
        officeTheme: profile.officeTheme,
        outfitStyle: profile.outfitStyle,
        accentColor: accent,
        personality: profile.personality,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function saveAuditRun(
  uid: string,
  auditId: string,
  title: string,
  sourceFormat: 'json' | 'csv' | 'text' | 'pos_log',
  rawSnippet: string,
  analysis: OperationalAnalysisResult
): Promise<string> {
  const safeId = sanitizeId(auditId);
  const path = `users/${uid}/audits/${safeId}`;
  try {
    await setDoc(doc(db, 'users', uid, 'audits', safeId), {
      ownerId: uid,
      title: clampStr(title, 160, 'Operational Audit'),
      sourceFormat,
      rawSnippet: rawSnippet.slice(0, 8000),
      netRevenuePhp: Number(analysis.salesSummary.netRevenuePhp.toFixed(2)),
      errorCount: Math.max(0, Math.floor(analysis.errors.length)),
      writeLockStatus: analysis.writeLockStatus,
      summaryMarkdown: clampStr(
        analysis.aiNarrative || analysis.sceneCue,
        12000,
        'Audit complete'
      ),
      botAnimation: analysis.bot3dState.animation,
      officeLighting: analysis.bot3dState.office_lighting,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return safeId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function confirmAuditRunInFirestore(
  uid: string,
  auditId: string,
  analysis: OperationalAnalysisResult
): Promise<void> {
  const safeId = sanitizeId(auditId);
  const path = `users/${uid}/audits/${safeId}`;
  try {
    await updateDoc(doc(db, 'users', uid, 'audits', safeId), {
      writeLockStatus: 'CONFIRMED_AND_EXPORTED',
      summaryMarkdown: clampStr(
        `CONFIRMED FIX: ${analysis.sceneCue}`,
        12000,
        'Confirmed'
      ),
      botAnimation: analysis.bot3dState.animation,
      officeLighting: analysis.bot3dState.office_lighting,
      errorCount: Math.max(0, Math.floor(analysis.errors.length)),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export function subscribeAudits(
  uid: string,
  onData: (audits: StoredAuditRun[]) => void,
  onError: (err: Error) => void
) {
  const path = `users/${uid}/audits`;
  const q = query(
    collection(db, 'users', uid, 'audits'),
    where('ownerId', '==', uid),
    orderBy('createdAt', 'desc'),
    limit(15)
  );
  return onSnapshot(
    q,
    (snapshot) => {
      const items: StoredAuditRun[] = snapshot.docs.map((d) => {
        const data = d.data();
        return {
          id: d.id,
          title: String(data.title || d.id),
          sourceFormat: String(data.sourceFormat || 'json'),
          netRevenuePhp: Number(data.netRevenuePhp || 0),
          errorCount: Number(data.errorCount || 0),
          writeLockStatus: data.writeLockStatus || 'AWAITING_CONFIRM_FIX',
          summaryMarkdown: String(data.summaryMarkdown || ''),
          botAnimation: String(data.botAnimation || 'scanning_hologram'),
          officeLighting: String(data.officeLighting || 'studio_blue'),
          createdAt: data.createdAt,
        };
      });
      onData(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
      }
    }
  );
}

export async function syncInventoryRows(
  uid: string,
  rows: InventoryHealthRow[]
): Promise<void> {
  for (const row of rows) {
    const safeId = sanitizeId(row.canonicalSku);
    const path = `users/${uid}/inventory/${safeId}`;
    try {
      await setDoc(doc(db, 'users', uid, 'inventory', safeId), {
        ownerId: uid,
        sku: safeId,
        name: clampStr(row.canonicalName, 160),
        category: clampStr(row.category, 80, 'General'),
        beginningStock: Math.max(0, Math.floor(row.beginningStock)),
        restocks: Math.max(0, Math.floor(row.restocks)),
        unitsSold: Math.max(0, Math.floor(row.unitsSold)),
        actualStock: Math.max(0, Math.floor(row.actualStock)),
        reorderThreshold: Math.max(0, Math.floor(row.reorderThreshold)),
        unitCostPhp: Math.max(0, Number(row.unitCostPhp.toFixed(2))),
        unitPricePhp: Math.max(0, Number(row.unitPricePhp.toFixed(2))),
        dailyVelocity: Math.max(0, Number(row.dailyVelocity.toFixed(2))),
        status: row.status,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }
}

export function subscribeInventory(
  uid: string,
  onData: (rows: InventoryHealthRow[]) => void,
  onError: (err: Error) => void
) {
  const path = `users/${uid}/inventory`;
  const q = query(
    collection(db, 'users', uid, 'inventory'),
    where('ownerId', '==', uid),
    limit(50)
  );
  return onSnapshot(
    q,
    (snapshot) => {
      const items: InventoryHealthRow[] = snapshot.docs.map((d) => {
        const data = d.data();
        const beginningStock = Number(data.beginningStock || 0);
        const restocks = Number(data.restocks || 0);
        const unitsSold = Number(data.unitsSold || 0);
        const actualStock = Number(data.actualStock || 0);
        const expectedEndingStock = beginningStock + restocks - unitsSold;
        const dailyVelocity = Number(data.dailyVelocity || 0);
        const unitCostPhp = Number(data.unitCostPhp || 0);
        const unitPricePhp = Number(data.unitPricePhp || 0);
        const marginPct =
          unitPricePhp > 0 && unitCostPhp > 0
            ? Number((((unitPricePhp - unitCostPhp) / unitPricePhp) * 100).toFixed(2))
            : null;
        return {
          canonicalSku: String(data.sku || d.id),
          canonicalName: String(data.name || d.id),
          category: String(data.category || 'General'),
          beginningStock,
          restocks,
          unitsSold,
          expectedEndingStock,
          actualStock,
          variance: actualStock - expectedEndingStock,
          reorderThreshold: Number(data.reorderThreshold || 5),
          dailyVelocity,
          daysUntilStockout:
            dailyVelocity > 0 ? Number((actualStock / dailyVelocity).toFixed(1)) : null,
          recommendedReorderQty:
            data.status === 'CRITICAL' || data.status === 'LOW_STOCK'
              ? Math.max(10 - actualStock, 5)
              : 0,
          status: data.status || 'HEALTHY',
          unitCostPhp,
          unitPricePhp,
          marginPct,
          lowMarginFlag: marginPct !== null && marginPct < 15,
        };
      });
      onData(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
      }
    }
  );
}
