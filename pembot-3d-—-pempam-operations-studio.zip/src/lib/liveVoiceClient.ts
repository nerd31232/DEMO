export interface LiveVoiceCallbacks {
  onStatusChange: (status: 'connecting' | 'connected' | 'closed' | 'error', detail?: string) => void;
  onSpeakingChange: (speaking: boolean) => void;
  onTranscript: (role: 'user' | 'bot', text: string) => void;
}

function float32ToInt16Base64(float32: Float32Array): string {
  const int16 = new Int16Array(float32.length);
  for (let i = 0; i < float32.length; i++) {
    const s = Math.max(-1, Math.min(1, float32[i]));
    int16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  const bytes = new Uint8Array(int16.buffer);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function base64ToInt16Array(b64: string): Int16Array {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new Int16Array(bytes.buffer);
}

export class LiveVoiceSession {
  private ws: WebSocket | null = null;
  private inputAudioCtx: AudioContext | null = null;
  private outputAudioCtx: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private nextStartTime = 0;
  private activeSources: Set<AudioBufferSourceNode> = new Set();
  private callbacks: LiveVoiceCallbacks;
  private closed = false;

  constructor(callbacks: LiveVoiceCallbacks) {
    this.callbacks = callbacks;
  }

  async start() {
    this.closed = false;
    this.callbacks.onStatusChange('connecting');

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/api/live`;
    this.ws = new WebSocket(wsUrl);

    this.inputAudioCtx = new AudioContext({ sampleRate: 16000 });
    this.outputAudioCtx = new AudioContext({ sampleRate: 24000 });
    this.nextStartTime = this.outputAudioCtx.currentTime;

    this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.sourceNode = this.inputAudioCtx.createMediaStreamSource(this.mediaStream);
    this.processor = this.inputAudioCtx.createScriptProcessor(4096, 1, 1);

    this.processor.onaudioprocess = (e) => {
      if (this.closed || !this.ws || this.ws.readyState !== WebSocket.OPEN) {
        return;
      }
      const channelData = e.inputBuffer.getChannelData(0);
      const base64 = float32ToInt16Base64(channelData);
      this.ws.send(JSON.stringify({ audio: base64 }));
    };

    this.sourceNode.connect(this.processor);
    this.processor.connect(this.inputAudioCtx.destination);

    this.ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.status === 'connected') {
          this.callbacks.onStatusChange('connected');
        } else if (msg.status === 'closed') {
          this.stop();
        } else if (msg.error) {
          this.callbacks.onStatusChange('error', msg.error);
        }

        if (msg.inputTranscript) {
          this.callbacks.onTranscript('user', msg.inputTranscript);
        }
        if (msg.outputTranscript) {
          this.callbacks.onTranscript('bot', msg.outputTranscript);
        }
        if (msg.audio) {
          this.playPcmChunk(msg.audio);
        }
        if (msg.interrupted) {
          this.clearPlaybackQueue();
        }
      } catch (err) {
        console.error('Live message parse error:', err);
      }
    };

    this.ws.onerror = () => {
      this.callbacks.onStatusChange('error', 'WebSocket connection failed.');
    };

    this.ws.onclose = () => {
      if (!this.closed) {
        this.stop();
      }
    };
  }

  sendTextContext(text: string) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN && text.trim()) {
      this.ws.send(JSON.stringify({ text: text.trim() }));
    }
  }

  private playPcmChunk(base64Pcm: string) {
    if (!this.outputAudioCtx) return;
    if (this.outputAudioCtx.state === 'suspended') {
      void this.outputAudioCtx.resume();
    }

    const int16 = base64ToInt16Array(base64Pcm);
    const float32 = new Float32Array(int16.length);
    for (let i = 0; i < int16.length; i++) {
      float32[i] = int16[i] / 32768;
    }

    const buffer = this.outputAudioCtx.createBuffer(1, float32.length, 24000);
    buffer.copyToChannel(float32, 0);

    const src = this.outputAudioCtx.createBufferSource();
    src.buffer = buffer;
    src.connect(this.outputAudioCtx.destination);

    const startAt = Math.max(
      this.outputAudioCtx.currentTime + 0.02,
      this.nextStartTime
    );
    src.start(startAt);
    this.nextStartTime = startAt + buffer.duration;
    this.activeSources.add(src);
    this.callbacks.onSpeakingChange(true);

    src.onended = () => {
      this.activeSources.delete(src);
      if (this.activeSources.size === 0) {
        this.callbacks.onSpeakingChange(false);
      }
    };
  }

  private clearPlaybackQueue() {
    for (const src of this.activeSources) {
      try {
        src.stop();
      } catch {
        // ignore already stopped
      }
    }
    this.activeSources.clear();
    if (this.outputAudioCtx) {
      this.nextStartTime = this.outputAudioCtx.currentTime;
    }
    this.callbacks.onSpeakingChange(false);
  }

  stop() {
    if (this.closed) return;
    this.closed = true;
    this.clearPlaybackQueue();

    try {
      this.processor?.disconnect();
      this.sourceNode?.disconnect();
    } catch {
      // ignore disconnect errors
    }

    this.mediaStream?.getTracks().forEach((t) => t.stop());
    void this.inputAudioCtx?.close();
    void this.outputAudioCtx?.close();

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.close();
    }

    this.ws = null;
    this.processor = null;
    this.sourceNode = null;
    this.mediaStream = null;
    this.inputAudioCtx = null;
    this.outputAudioCtx = null;
    this.callbacks.onSpeakingChange(false);
    this.callbacks.onStatusChange('closed');
  }
}
