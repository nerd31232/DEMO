export type OfficeTheme = 'daylight_studio' | 'cyberpunk_night' | 'minimalist_warehouse';

export type OutfitStyle =
  | 'standard_chassis'
  | 'formal_barong'
  | 'cyber_visor'
  | 'executive_slate';

export type PersonalityMode =
  | 'friendly_coworker'
  | 'strict_auditor'
  | 'executive_briefing';

export type BotAnimationState =
  | 'scanning_hologram'
  | 'celebrating'
  | 'warning_alert'
  | 'repairing_code'
  | 'shield_locked';

export type BotExpressionState = 'happy' | 'focused' | 'alert' | 'protective';

export type OfficeLightingState =
  | 'studio_blue'
  | 'celebration_gold'
  | 'caution_amber'
  | 'quarantine_red';

export type HologramScreenType =
  | 'sales_chart'
  | 'inventory_grid'
  | 'error_diff_terminal';

export type WriteLockStatus = 'AWAITING_CONFIRM_FIX' | 'CONFIRMED_AND_EXPORTED';

export interface BotCustomizationProfile {
  botName: string;
  companyName: string;
  officeTheme: OfficeTheme;
  outfitStyle: OutfitStyle;
  accentColor: string;
  personality: PersonalityMode;
}

export interface Bot3DState {
  bot_name: string;
  animation: BotAnimationState;
  expression: BotExpressionState;
  office_lighting: OfficeLightingState;
  hologram_screens: HologramScreenType[];
  write_lock_status: WriteLockStatus;
}

export interface RawSaleLineItem {
  sku: string;
  name: string;
  qty: number;
  unitPricePhp: number;
  unitCostPhp?: number;
  promoTag?: string;
}

export interface RawReceiptRecord {
  receiptId: string;
  date: string;
  paymentMethod?: string;
  discountPhp?: number;
  reportedTotalPhp?: number | null;
  customerNote?: string;
  items: RawSaleLineItem[];
}

export interface RawInventoryRecord {
  sku: string;
  name: string;
  category: string;
  beginningStock: number;
  restocks: number;
  unitsSoldReported?: number;
  actualStock: number;
  reorderThreshold?: number;
  unitCostPhp?: number;
  unitPricePhp?: number;
  periodDays?: number;
}

export interface OperationalBatchInput {
  batchTitle?: string;
  periodDays?: number;
  receipts: RawReceiptRecord[];
  inventory: RawInventoryRecord[];
  previousPeriodNetRevenuePhp?: number;
}

export interface ProductPerformanceRow {
  canonicalSku: string;
  canonicalName: string;
  unitsSold: number;
  revenuePhp: number;
  unitCostPhp: number | null;
  grossProfitPhp: number | null;
  marginPct: number | null;
  lowMarginFlag: boolean;
}

export interface PaymentSplitRow {
  method: string;
  transactions: number;
  totalPhp: number;
  sharePct: number;
}

export type StockStatus = 'CRITICAL' | 'LOW_STOCK' | 'HEALTHY' | 'OVERSTOCK';

export interface InventoryHealthRow {
  canonicalSku: string;
  canonicalName: string;
  category: string;
  beginningStock: number;
  restocks: number;
  unitsSold: number;
  expectedEndingStock: number;
  actualStock: number;
  variance: number;
  reorderThreshold: number;
  dailyVelocity: number;
  daysUntilStockout: number | null;
  recommendedReorderQty: number;
  status: StockStatus;
  unitCostPhp: number;
  unitPricePhp: number;
  marginPct: number | null;
  lowMarginFlag: boolean;
}

export type ErrorSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM';

export interface ProposedFixRecord {
  errorId: string;
  severity: ErrorSeverity;
  recordRef: string;
  issueType: string;
  rootCause: string;
  beforeValue: string;
  afterValue: string;
  autoRepairable: boolean;
}

export interface QuarantineRecord {
  quarantineId: string;
  recordRef: string;
  reason: string;
  reportedAmountPhp: number | null;
  date: string;
}

export interface EntityNormalizationSuggestion {
  canonicalSku: string;
  canonicalName: string;
  mergedVariants: string[];
}

export interface AuditChangeLogEntry {
  timestampManila: string;
  action: string;
  errorIds: string[];
  note: string;
}

export interface OperationalAnalysisResult {
  sceneCue: string;
  actionRequiredToday: string[];
  salesSummary: {
    grossSalesPhp: number;
    discountsPhp: number;
    netRevenuePhp: number;
    totalTransactions: number;
    averageOrderValuePhp: number;
    wowTrendPct: number | null;
    missingDataCount: number;
    topProducts: ProductPerformanceRow[];
    slowMovers: string[];
    paymentBreakdown: PaymentSplitRow[];
  };
  inventoryHealth: InventoryHealthRow[];
  errors: ProposedFixRecord[];
  quarantine: QuarantineRecord[];
  normalizations: EntityNormalizationSuggestion[];
  redactedSecretsCount: number;
  promptInjectionsBlocked: number;
  writeLockStatus: WriteLockStatus;
  repairedPayload: OperationalBatchInput | null;
  auditChangeLog: AuditChangeLogEntry[];
  bot3dState: Bot3DState;
  aiNarrative?: string;
  modelUsed?: string;
  thinkingMode?: 'fast' | 'deep';
}

export interface CalendarEventItem {
  id: string;
  summary: string;
  start: string;
  end: string;
  description?: string;
  location?: string;
  htmlLink?: string;
}

export interface PendingCalendarAction {
  summary: string;
  startIso: string;
  endIso: string;
  description: string;
  location: string;
}
