import * as THREE from 'three';
import {
  BotAnimationState,
  BotCustomizationProfile,
  BotExpressionState,
} from '../types/operations';
import {
  createRadialShadowTexture,
  drawBadgeTexture,
  drawVisorFace,
} from './proceduralTextures';

export interface PemBotRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  headGroup: THREE.Group;
  leftArmGroup: THREE.Group;
  rightArmGroup: THREE.Group;
  gogglesGroup: THREE.Group;
  barongGroup: THREE.Group;
  holoLeftPlate: THREE.Mesh;
  holoRightPlate: THREE.Mesh;
  antennaTip: THREE.Mesh;
  updateProfile: (profile: BotCustomizationProfile, maxAnisotropy: number) => void;
  updateFrame: (
    elapsed: number,
    delta: number,
    animState: BotAnimationState,
    expression: BotExpressionState,
    accentHex: string,
    isSpeaking: boolean
  ) => void;
  dispose: () => void;
}

export function createPemBot(
  initialProfile: BotCustomizationProfile,
  maxAnisotropy: number
): PemBotRig {
  const root = new THREE.Group();
  root.name = 'PemBotRoot';

  const disposables: Array<{ dispose: () => void }> = [];
  const track = <T extends { dispose: () => void }>(item: T): T => {
    disposables.push(item);
    return item;
  };

  // 1. Contact Shadow Disc at y = 0.015
  const shadowTex = track(createRadialShadowTexture());
  const shadowGeo = track(new THREE.CircleGeometry(0.95, 32));
  const shadowMat = track(
    new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.72,
    })
  );
  const shadowDisc = new THREE.Mesh(shadowGeo, shadowMat);
  shadowDisc.rotation.x = -Math.PI / 2;
  shadowDisc.position.y = 0.015;
  root.add(shadowDisc);

  // Materials with explicit roughness/metalness contrast
  const chassisMat = track(
    new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      roughness: 0.55,
      metalness: 0.14,
    })
  );
  const trimMat = track(
    new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.22,
      metalness: 0.88,
    })
  );
  const accentMat = track(
    new THREE.MeshStandardMaterial({
      color: new THREE.Color(initialProfile.accentColor),
      roughness: 0.32,
      metalness: 0.45,
      emissive: new THREE.Color(initialProfile.accentColor),
      emissiveIntensity: 0.25,
    })
  );

  // 2. Lathe Omni-Base Pedestal (bottom-center flush at y = 0)
  const basePoints = [
    new THREE.Vector2(0.0, 0.0),
    new THREE.Vector2(0.54, 0.0),
    new THREE.Vector2(0.56, 0.08),
    new THREE.Vector2(0.46, 0.22),
    new THREE.Vector2(0.28, 0.38),
    new THREE.Vector2(0.18, 0.48),
    new THREE.Vector2(0.0, 0.48),
  ];
  const baseGeo = track(new THREE.LatheGeometry(basePoints, 28));
  const baseMesh = new THREE.Mesh(baseGeo, trimMat);
  baseMesh.castShadow = true;
  baseMesh.receiveShadow = true;
  root.add(baseMesh);

  const hoverRingGeo = track(new THREE.TorusGeometry(0.49, 0.028, 12, 36));
  const hoverRing = new THREE.Mesh(hoverRingGeo, accentMat);
  hoverRing.rotation.x = Math.PI / 2;
  hoverRing.position.y = 0.14;
  root.add(hoverRing);

  // Articulated Body Group
  const bodyGroup = new THREE.Group();
  bodyGroup.position.y = 0.48;
  root.add(bodyGroup);

  // 3. Bevelled Extruded Torso Silhouette
  const torsoShape = new THREE.Shape();
  torsoShape.moveTo(-0.38, 0);
  torsoShape.lineTo(0.38, 0);
  torsoShape.quadraticCurveTo(0.48, 0.35, 0.44, 0.78);
  torsoShape.quadraticCurveTo(0.38, 0.92, 0.0, 0.94);
  torsoShape.quadraticCurveTo(-0.38, 0.92, -0.44, 0.78);
  torsoShape.quadraticCurveTo(-0.48, 0.35, -0.38, 0);

  const torsoGeo = track(
    new THREE.ExtrudeGeometry(torsoShape, {
      depth: 0.42,
      bevelEnabled: true,
      bevelThickness: 0.08,
      bevelSize: 0.06,
      bevelSegments: 4,
    })
  );
  torsoGeo.center();
  const torsoMesh = new THREE.Mesh(torsoGeo, chassisMat);
  torsoMesh.position.y = 0.56;
  torsoMesh.castShadow = true;
  torsoMesh.receiveShadow = true;
  bodyGroup.add(torsoMesh);

  // 4. Company Chest Badge (CanvasTexture)
  const badgeCanvas = document.createElement('canvas');
  badgeCanvas.width = 256;
  badgeCanvas.height = 112;
  const badgeCtx = badgeCanvas.getContext('2d')!;
  drawBadgeTexture(
    badgeCtx,
    initialProfile.companyName,
    initialProfile.botName,
    initialProfile.accentColor
  );
  const badgeTex = track(new THREE.CanvasTexture(badgeCanvas));
  badgeTex.colorSpace = THREE.SRGBColorSpace;
  badgeTex.anisotropy = maxAnisotropy;
  const badgeGeo = track(new THREE.PlaneGeometry(0.36, 0.16));
  const badgeMat = track(
    new THREE.MeshStandardMaterial({
      map: badgeTex,
      roughness: 0.35,
      metalness: 0.1,
    })
  );
  const badgeMesh = new THREE.Mesh(badgeGeo, badgeMat);
  badgeMesh.position.set(0.18, 0.68, 0.3);
  bodyGroup.add(badgeMesh);

  // 5. Optional Formal Barong Placket / Collar Group
  const barongGroup = new THREE.Group();
  const barongFabricMat = track(
    new THREE.MeshStandardMaterial({
      color: 0xfef3c7,
      roughness: 0.85,
      metalness: 0.02,
    })
  );
  const barongEmbroideryMat = track(
    new THREE.MeshStandardMaterial({
      color: 0xd97706,
      roughness: 0.6,
      metalness: 0.15,
    })
  );
  const barongChest = new THREE.Mesh(
    track(new THREE.BoxGeometry(0.92, 0.86, 0.56)),
    barongFabricMat
  );
  barongChest.position.set(0, 0.55, 0.01);
  barongGroup.add(barongChest);

  const barongPlacket = new THREE.Mesh(
    track(new THREE.BoxGeometry(0.19, 0.7, 0.03)),
    barongEmbroideryMat
  );
  barongPlacket.position.set(-0.14, 0.56, 0.29);
  barongGroup.add(barongPlacket);

  const barongCollar = new THREE.Mesh(
    track(new THREE.TorusGeometry(0.22, 0.04, 10, 24)),
    barongFabricMat
  );
  barongCollar.rotation.x = Math.PI / 2;
  barongCollar.position.set(0, 1.0, 0);
  barongGroup.add(barongCollar);
  barongGroup.visible = initialProfile.outfitStyle === 'formal_barong';
  bodyGroup.add(barongGroup);

  // 6. Neck + Head Group
  const neckMesh = new THREE.Mesh(
    track(new THREE.CylinderGeometry(0.14, 0.17, 0.18, 16)),
    trimMat
  );
  neckMesh.position.y = 1.08;
  bodyGroup.add(neckMesh);

  const headGroup = new THREE.Group();
  headGroup.position.y = 1.46;
  bodyGroup.add(headGroup);

  const headShape = new THREE.Shape();
  headShape.moveTo(-0.34, -0.22);
  headShape.lineTo(0.34, -0.22);
  headShape.quadraticCurveTo(0.42, 0, 0.34, 0.24);
  headShape.quadraticCurveTo(0, 0.32, -0.34, 0.24);
  headShape.quadraticCurveTo(-0.42, 0, -0.34, -0.22);
  const headGeo = track(
    new THREE.ExtrudeGeometry(headShape, {
      depth: 0.38,
      bevelEnabled: true,
      bevelThickness: 0.08,
      bevelSize: 0.07,
      bevelSegments: 4,
    })
  );
  headGeo.center();
  const headShell = new THREE.Mesh(headGeo, chassisMat);
  headShell.castShadow = true;
  headGroup.add(headShell);

  // Expressive LED Visor Screen
  const visorCanvas = document.createElement('canvas');
  visorCanvas.width = 512;
  visorCanvas.height = 256;
  const visorCtx = visorCanvas.getContext('2d')!;
  drawVisorFace(visorCtx, 'happy', initialProfile.accentColor, false, 0);
  const visorTex = track(new THREE.CanvasTexture(visorCanvas));
  visorTex.colorSpace = THREE.SRGBColorSpace;
  visorTex.anisotropy = maxAnisotropy;

  const visorGeo = track(new THREE.PlaneGeometry(0.64, 0.32));
  const visorMat = track(
    new THREE.MeshStandardMaterial({
      map: visorTex,
      emissiveMap: visorTex,
      emissive: new THREE.Color(0xffffff),
      emissiveIntensity: 0.9,
      roughness: 0.08,
      metalness: 0.1,
    })
  );
  const visorScreen = new THREE.Mesh(visorGeo, visorMat);
  visorScreen.position.z = 0.275;
  headGroup.add(visorScreen);

  // Side Ear Pods
  const earGeo = track(new THREE.CylinderGeometry(0.11, 0.11, 0.08, 18));
  const leftEar = new THREE.Mesh(earGeo, accentMat);
  leftEar.rotation.z = Math.PI / 2;
  leftEar.position.set(-0.46, 0, 0);
  headGroup.add(leftEar);

  const rightEar = new THREE.Mesh(earGeo, accentMat);
  rightEar.rotation.z = Math.PI / 2;
  rightEar.position.set(0.46, 0, 0);
  headGroup.add(rightEar);

  // Antenna + Beacon Tip
  const antennaStem = new THREE.Mesh(
    track(new THREE.CylinderGeometry(0.02, 0.025, 0.24, 10)),
    trimMat
  );
  antennaStem.position.set(0, 0.42, -0.04);
  headGroup.add(antennaStem);

  const antennaTipMat = track(
    new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x38bdf8,
      emissiveIntensity: 1.4,
      roughness: 0.2,
    })
  );
  const antennaTip = new THREE.Mesh(
    track(new THREE.SphereGeometry(0.055, 16, 16)),
    antennaTipMat
  );
  antennaTip.position.set(0, 0.56, -0.04);
  headGroup.add(antennaTip);

  // 7. Flip-down Diagnostic Cyber-Goggles
  const gogglesGroup = new THREE.Group();
  gogglesGroup.position.set(0, 0.18, 0.27);
  const goggleFrameMat = track(
    new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.25,
      metalness: 0.85,
    })
  );
  const goggleLensMat = track(
    new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      emissive: 0xf59e0b,
      emissiveIntensity: 0.55,
      transparent: true,
      opacity: 0.62,
      roughness: 0.1,
    })
  );
  const lensGeo = track(new THREE.CylinderGeometry(0.11, 0.11, 0.04, 20));
  const gLeft = new THREE.Mesh(lensGeo, goggleLensMat);
  gLeft.rotation.x = Math.PI / 2;
  gLeft.position.set(-0.15, -0.14, 0.04);
  const gRight = new THREE.Mesh(lensGeo, goggleLensMat);
  gRight.rotation.x = Math.PI / 2;
  gRight.position.set(0.15, -0.14, 0.04);
  const bridge = new THREE.Mesh(
    track(new THREE.BoxGeometry(0.62, 0.045, 0.05)),
    goggleFrameMat
  );
  bridge.position.set(0, -0.14, 0.03);
  gogglesGroup.add(gLeft, gRight, bridge);
  gogglesGroup.rotation.x = -Math.PI * 0.55; // resting up on forehead
  headGroup.add(gogglesGroup);

  // 8. Multi-Tasking Articulated Holographic Arms
  const holoMat = track(
    new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.52,
      side: THREE.DoubleSide,
    })
  );

  function buildArm(side: -1 | 1) {
    const armGroup = new THREE.Group();
    armGroup.position.set(side * 0.56, 0.84, 0);

    const shoulder = new THREE.Mesh(
      track(new THREE.SphereGeometry(0.11, 16, 16)),
      trimMat
    );
    armGroup.add(shoulder);

    const upperArm = new THREE.Mesh(
      track(new THREE.CylinderGeometry(0.065, 0.055, 0.34, 14)),
      chassisMat
    );
    upperArm.position.y = -0.2;
    upperArm.castShadow = true;
    armGroup.add(upperArm);

    const forearmCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, -0.36, 0),
      new THREE.Vector3(side * 0.04, -0.54, 0.14),
      new THREE.Vector3(side * 0.02, -0.62, 0.3),
    ]);
    const forearm = new THREE.Mesh(
      track(new THREE.TubeGeometry(forearmCurve, 12, 0.052, 10, false)),
      trimMat
    );
    forearm.castShadow = true;
    armGroup.add(forearm);

    const wristRing = new THREE.Mesh(
      track(new THREE.TorusGeometry(0.08, 0.015, 8, 20)),
      accentMat
    );
    wristRing.position.set(side * 0.02, -0.62, 0.31);
    armGroup.add(wristRing);

    const holoPlate = new THREE.Mesh(
      track(new THREE.PlaneGeometry(0.28, 0.18)),
      holoMat
    );
    holoPlate.position.set(side * 0.02, -0.5, 0.45);
    holoPlate.rotation.x = -0.4;
    armGroup.add(holoPlate);

    return { armGroup, holoPlate };
  }

  const left = buildArm(-1);
  const right = buildArm(1);
  bodyGroup.add(left.armGroup, right.armGroup);

  let currentProfile = { ...initialProfile };
  let lastVisorRedraw = 0;

  const updateProfile = (
    profile: BotCustomizationProfile,
    anisotropy: number
  ) => {
    currentProfile = { ...profile };
    const accent = new THREE.Color(profile.accentColor || '#2563eb');
    accentMat.color.copy(accent);
    accentMat.emissive.copy(accent);

    if (profile.outfitStyle === 'executive_slate') {
      chassisMat.color.setHex(0x1e293b);
      trimMat.color.setHex(0x94a3b8);
    } else if (profile.outfitStyle === 'cyber_visor') {
      chassisMat.color.setHex(0x0f172a);
      trimMat.color.setHex(0x38bdf8);
    } else {
      chassisMat.color.setHex(0xf1f5f9);
      trimMat.color.setHex(0x334155);
    }

    barongGroup.visible = profile.outfitStyle === 'formal_barong';

    drawBadgeTexture(
      badgeCtx,
      profile.companyName,
      profile.botName,
      profile.accentColor
    );
    badgeTex.anisotropy = anisotropy;
    badgeTex.needsUpdate = true;
  };

  const updateFrame = (
    elapsed: number,
    delta: number,
    animState: BotAnimationState,
    expression: BotExpressionState,
    accentHex: string,
    isSpeaking: boolean
  ) => {
    // Gentle hover breathing
    const bob = Math.sin(elapsed * 2.1) * 0.03;
    bodyGroup.position.y = THREE.MathUtils.damp(
      bodyGroup.position.y,
      0.48 + bob,
      8,
      delta
    );

    let targetLeftX = -0.15;
    let targetRightX = -0.15;
    let targetLeftZ = 0.08;
    let targetRightZ = -0.08;
    let targetHeadY = Math.sin(elapsed * 0.7) * 0.1;
    let targetHeadX = 0;
    let targetGogglesX =
      currentProfile.outfitStyle === 'cyber_visor' ? 0.08 : -Math.PI * 0.55;

    if (animState === 'celebrating') {
      targetLeftX = -2.2 + Math.sin(elapsed * 6) * 0.18;
      targetRightX = -2.2 - Math.sin(elapsed * 6) * 0.18;
      targetLeftZ = 0.35;
      targetRightZ = -0.35;
      targetHeadX = -0.1;
      antennaTipMat.color.setHex(0xfbbf24);
      antennaTipMat.emissive.setHex(0xfbbf24);
    } else if (animState === 'warning_alert') {
      targetLeftX = -0.85;
      targetRightX = -0.55 + Math.sin(elapsed * 4) * 0.12;
      targetHeadY = Math.sin(elapsed * 2.4) * 0.25;
      targetGogglesX = 0.08; // flip down cyber-goggles!
      antennaTipMat.color.setHex(0xf59e0b);
      antennaTipMat.emissive.setHex(0xf59e0b);
    } else if (animState === 'repairing_code') {
      targetLeftX = -0.95 + Math.sin(elapsed * 8) * 0.14;
      targetRightX = -0.95 + Math.cos(elapsed * 8) * 0.14;
      targetHeadX = 0.14;
      antennaTipMat.color.setHex(0x10b981);
      antennaTipMat.emissive.setHex(0x10b981);
    } else if (animState === 'shield_locked') {
      targetLeftX = -1.1;
      targetRightX = -1.1;
      targetLeftZ = -0.32;
      targetRightZ = 0.32;
      antennaTipMat.color.setHex(0xef4444);
      antennaTipMat.emissive.setHex(0xef4444);
    } else {
      // scanning_hologram
      targetLeftX = -0.65 + Math.sin(elapsed * 2.2) * 0.1;
      targetRightX = -0.75 + Math.cos(elapsed * 2.2) * 0.1;
      antennaTipMat.color.set(accentHex || '#38bdf8');
      antennaTipMat.emissive.set(accentHex || '#38bdf8');
    }

    if (isSpeaking) {
      targetHeadX += Math.sin(elapsed * 9) * 0.04;
      targetRightX -= 0.25 + Math.sin(elapsed * 7) * 0.12;
    }

    left.armGroup.rotation.x = THREE.MathUtils.damp(
      left.armGroup.rotation.x,
      targetLeftX,
      7,
      delta
    );
    right.armGroup.rotation.x = THREE.MathUtils.damp(
      right.armGroup.rotation.x,
      targetRightX,
      7,
      delta
    );
    left.armGroup.rotation.z = THREE.MathUtils.damp(
      left.armGroup.rotation.z,
      targetLeftZ,
      7,
      delta
    );
    right.armGroup.rotation.z = THREE.MathUtils.damp(
      right.armGroup.rotation.z,
      targetRightZ,
      7,
      delta
    );
    headGroup.rotation.y = THREE.MathUtils.damp(
      headGroup.rotation.y,
      targetHeadY,
      6,
      delta
    );
    headGroup.rotation.x = THREE.MathUtils.damp(
      headGroup.rotation.x,
      targetHeadX,
      6,
      delta
    );
    gogglesGroup.rotation.x = THREE.MathUtils.damp(
      gogglesGroup.rotation.x,
      targetGogglesX,
      8,
      delta
    );

    const showHolo =
      animState === 'scanning_hologram' ||
      animState === 'repairing_code' ||
      animState === 'warning_alert';
    left.holoPlate.visible = showHolo;
    right.holoPlate.visible = showHolo;

    // Redraw visor face ~12fps or whenever speaking
    if (elapsed - lastVisorRedraw > (isSpeaking ? 0.06 : 0.2)) {
      lastVisorRedraw = elapsed;
      drawVisorFace(visorCtx, expression, accentHex, isSpeaking, elapsed);
      visorTex.needsUpdate = true;
    }
  };

  return {
    root,
    bodyGroup,
    headGroup,
    leftArmGroup: left.armGroup,
    rightArmGroup: right.armGroup,
    gogglesGroup,
    barongGroup,
    holoLeftPlate: left.holoPlate,
    holoRightPlate: right.holoPlate,
    antennaTip,
    updateProfile,
    updateFrame,
    dispose: () => {
      for (const item of disposables) {
        item.dispose();
      }
    },
  };
}
