import * as THREE from 'three';
import {
  BotExpressionState,
  OfficeTheme,
  OperationalAnalysisResult,
} from '../types/operations';

export function createRadialShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(128, 128, 12, 128, 128, 124);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.55)');
  grad.addColorStop(0.5, 'rgba(0, 0, 0, 0.22)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createFloorTextures(
  theme: OfficeTheme,
  maxAnisotropy: number
): {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const size = 512;
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = size;
  colorCanvas.height = size;
  const ctx = colorCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = size;
  bumpCanvas.height = size;
  const bCtx = bumpCanvas.getContext('2d')!;

  if (theme === 'cyberpunk_night') {
    ctx.fillStyle = '#111827';
  } else if (theme === 'minimalist_warehouse') {
    ctx.fillStyle = '#cbd5e1';
  } else {
    ctx.fillStyle = '#e2e8f0';
  }
  ctx.fillRect(0, 0, size, size);

  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, size, size);

  // Subtle tile seams + micro-speckle texture
  const tile = 128;
  ctx.strokeStyle =
    theme === 'cyberpunk_night'
      ? 'rgba(56, 189, 248, 0.14)'
      : 'rgba(15, 23, 42, 0.08)';
  ctx.lineWidth = 2;

  bCtx.strokeStyle = '#404040';
  bCtx.lineWidth = 3;

  for (let i = 0; i <= size; i += tile) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, size);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(size, i);
    ctx.stroke();

    bCtx.beginPath();
    bCtx.moveTo(i, 0);
    bCtx.lineTo(i, size);
    bCtx.stroke();
    bCtx.beginPath();
    bCtx.moveTo(0, i);
    bCtx.lineTo(size, i);
    bCtx.stroke();
  }

  for (let i = 0; i < 900; i++) {
    const x = (i * 73) % size;
    const y = (i * 137) % size;
    ctx.fillStyle =
      theme === 'cyberpunk_night'
        ? 'rgba(255,255,255,0.025)'
        : 'rgba(15,23,42,0.025)';
    ctx.fillRect(x, y, 2, 2);
    bCtx.fillStyle = i % 2 === 0 ? '#909090' : '#707070';
    bCtx.fillRect(x, y, 2, 2);
  }

  const map = new THREE.CanvasTexture(colorCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(6, 6);
  map.anisotropy = maxAnisotropy;

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.RepeatWrapping;
  bumpMap.repeat.set(6, 6);
  bumpMap.anisotropy = maxAnisotropy;

  return { map, bumpMap };
}

export function drawVisorFace(
  ctx: CanvasRenderingContext2D,
  expression: BotExpressionState,
  accentHex: string,
  speaking: boolean,
  time: number
) {
  const w = ctx.canvas.width;
  const h = ctx.canvas.height;
  ctx.clearRect(0, 0, w, h);

  ctx.fillStyle = '#070b14';
  ctx.fillRect(0, 0, w, h);

  // Subtle scanlines
  ctx.fillStyle = 'rgba(255,255,255,0.04)';
  for (let y = 0; y < h; y += 6) {
    ctx.fillRect(0, y, w, 1);
  }

  const color =
    expression === 'alert'
      ? '#f59e0b'
      : expression === 'protective'
        ? '#ef4444'
        : accentHex || '#38bdf8';

  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = 10;
  ctx.lineCap = 'round';
  ctx.shadowColor = color;
  ctx.shadowBlur = 16;

  // Left and Right Eyes
  const eyeY = h * 0.42;
  const leftX = w * 0.32;
  const rightX = w * 0.68;

  if (expression === 'happy') {
    // Cheerful curved visor arcs
    ctx.beginPath();
    ctx.arc(leftX, eyeY + 10, 26, Math.PI * 1.12, Math.PI * 1.88);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(rightX, eyeY + 10, 26, Math.PI * 1.12, Math.PI * 1.88);
    ctx.stroke();
  } else if (expression === 'alert') {
    // Diagnostic chevrons
    ctx.beginPath();
    ctx.moveTo(leftX - 24, eyeY - 12);
    ctx.lineTo(leftX + 16, eyeY);
    ctx.lineTo(leftX - 24, eyeY + 14);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(rightX + 24, eyeY - 12);
    ctx.lineTo(rightX - 16, eyeY);
    ctx.lineTo(rightX + 24, eyeY + 14);
    ctx.stroke();
  } else if (expression === 'protective') {
    // Shield bars
    ctx.fillRect(leftX - 24, eyeY - 8, 48, 16);
    ctx.fillRect(rightX - 24, eyeY - 8, 48, 16);
  } else {
    // Focused glowing oval eyes
    ctx.beginPath();
    ctx.ellipse(leftX, eyeY, 20, 26, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(rightX, eyeY, 20, 26, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Mouth / Voice waveform
  ctx.shadowBlur = 8;
  const mouthY = h * 0.74;
  if (speaking) {
    const bars = 9;
    const spacing = 18;
    const startX = w / 2 - ((bars - 1) * spacing) / 2;
    for (let i = 0; i < bars; i++) {
      const amp =
        10 + Math.abs(Math.sin(time * 12 + i * 0.9)) * 22;
      ctx.fillRect(startX + i * spacing - 4, mouthY - amp / 2, 8, amp);
    }
  } else {
    ctx.lineWidth = 6;
    ctx.beginPath();
    if (expression === 'happy') {
      ctx.arc(w / 2, mouthY - 8, 22, 0.2, Math.PI - 0.2);
    } else if (expression === 'alert') {
      ctx.moveTo(w / 2 - 24, mouthY);
      ctx.lineTo(w / 2 + 24, mouthY);
    } else {
      ctx.arc(w / 2, mouthY - 4, 16, 0.35, Math.PI - 0.35);
    }
    ctx.stroke();
  }
}

export function drawBadgeTexture(
  ctx: CanvasRenderingContext2D,
  companyName: string,
  botName: string,
  accentHex: string
) {
  const w = ctx.canvas.width;
  const h = ctx.canvas.height;
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(0, 0, w, h);

  ctx.fillStyle = accentHex || '#2563eb';
  ctx.fillRect(0, 0, 18, h);

  ctx.fillStyle = '#94a3b8';
  ctx.font = '600 18px sans-serif';
  ctx.fillText(companyName.toUpperCase().slice(0, 16), 30, 40);

  ctx.fillStyle = '#f8fafc';
  ctx.font = '700 28px sans-serif';
  ctx.fillText(botName.slice(0, 16), 30, 78);
}

export function drawMonitorTexture(
  ctx: CanvasRenderingContext2D,
  screenType: 'sales_chart' | 'inventory_grid' | 'error_diff_terminal',
  analysis: OperationalAnalysisResult | null,
  accentHex: string
) {
  const w = ctx.canvas.width;
  const h = ctx.canvas.height;

  ctx.fillStyle = '#0b1120';
  ctx.fillRect(0, 0, w, h);

  ctx.strokeStyle = accentHex || '#38bdf8';
  ctx.lineWidth = 3;
  ctx.strokeRect(8, 8, w - 16, h - 16);

  ctx.fillStyle = '#e2e8f0';
  ctx.font = '700 22px sans-serif';

  if (screenType === 'sales_chart') {
    ctx.fillText('SALES ANALYTICS (PHP)', 26, 44);
    const net = analysis?.salesSummary.netRevenuePhp ?? 0;
    const tx = analysis?.salesSummary.totalTransactions ?? 0;
    ctx.fillStyle = '#38bdf8';
    ctx.font = '700 34px monospace';
    ctx.fillText(`PHP ${net.toLocaleString('en-PH', { minimumFractionDigits: 2 })}`, 26, 90);
    ctx.fillStyle = '#94a3b8';
    ctx.font = '500 18px monospace';
    ctx.fillText(`Verified Txns: ${tx}`, 26, 120);

    // Mini bar chart
    const bars = (analysis?.salesSummary.topProducts ?? []).slice(0, 5);
    const maxRev = Math.max(1, ...bars.map((b) => b.revenuePhp));
    bars.forEach((b, idx) => {
      const barH = Math.max(16, (b.revenuePhp / maxRev) * 110);
      const x = 34 + idx * 90;
      const y = h - 32 - barH;
      ctx.fillStyle = b.lowMarginFlag ? '#f59e0b' : '#10b981';
      ctx.fillRect(x, y, 56, barH);
      ctx.fillStyle = '#cbd5e1';
      ctx.font = '500 13px monospace';
      ctx.fillText(b.canonicalSku.slice(0, 8), x, h - 12);
    });
  } else if (screenType === 'inventory_grid') {
    ctx.fillText('STOCK HEALTH MONITOR', 26, 44);
    const rows = (analysis?.inventoryHealth ?? []).slice(0, 5);
    rows.forEach((row, idx) => {
      const y = 84 + idx * 42;
      ctx.fillStyle =
        row.status === 'CRITICAL'
          ? '#ef4444'
          : row.status === 'LOW_STOCK'
            ? '#f59e0b'
            : row.status === 'OVERSTOCK'
              ? '#818cf8'
              : '#10b981';
      ctx.fillRect(26, y - 16, 12, 22);

      ctx.fillStyle = '#f8fafc';
      ctx.font = '600 17px monospace';
      ctx.fillText(row.canonicalName.slice(0, 22), 48, y);

      ctx.fillStyle = '#cbd5e1';
      ctx.fillText(`${row.actualStock} u · ${row.status}`, 335, y);
    });
  } else {
    ctx.fillText('ERROR FIXER & WRITE LOCK', 26, 44);
    const errs = analysis?.errors ?? [];
    const lock = analysis?.writeLockStatus ?? 'AWAITING_CONFIRM_FIX';
    ctx.fillStyle =
      lock === 'CONFIRMED_AND_EXPORTED' ? '#10b981' : '#f59e0b';
    ctx.font = '700 18px monospace';
    ctx.fillText(`LOCK: ${lock}`, 26, 78);

    errs.slice(0, 4).forEach((err, idx) => {
      const y = 118 + idx * 42;
      ctx.fillStyle = err.severity === 'CRITICAL' ? '#f87171' : '#fbbf24';
      ctx.font = '700 16px monospace';
      ctx.fillText(`${err.errorId} ${err.issueType.slice(0, 28)}`, 26, y);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '400 14px monospace';
      ctx.fillText(`${err.beforeValue.slice(0, 20)} -> ${err.afterValue.slice(0, 20)}`, 26, y + 18);
    });
  }
}
