import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  Bot3DState,
  BotCustomizationProfile,
  OfficeTheme,
  OperationalAnalysisResult,
} from '../types/operations';
import { createPemBot, PemBotRig } from './createPemBot';
import {
  createFloorTextures,
  drawMonitorTexture,
} from './proceduralTextures';

export type CameraPreset = 'desk' | 'portrait' | 'stockroom';

interface OfficeViewportProps {
  profile: BotCustomizationProfile;
  bot3dState: Bot3DState;
  analysis: OperationalAnalysisResult | null;
  cameraPreset: CameraPreset;
  isSpeaking: boolean;
  drawerOpen: boolean;
}

const CAMERA_TARGETS: Record<
  CameraPreset,
  { pos: [number, number, number]; target: [number, number, number] }
> = {
  desk: { pos: [0.4, 2.25, 4.7], target: [0.0, 1.35, 0.0] },
  portrait: { pos: [-0.9, 1.85, 2.55], target: [0.0, 1.48, 0.0] },
  stockroom: { pos: [4.1, 3.0, 5.2], target: [0.8, 1.3, -1.2] },
};

// Scratch vectors allocated once outside animation loop
const _desiredCamPos = new THREE.Vector3();
const _desiredTarget = new THREE.Vector3();
const _targetBeaconColor = new THREE.Color();

export const OfficeViewport: React.FC<OfficeViewportProps> = ({
  profile,
  bot3dState,
  analysis,
  cameraPreset,
  isSpeaking,
  drawerOpen,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [contextLost, setContextLost] = useState(false);

  // Store live React props in refs so WebGL scene never tears down on state changes
  const profileRef = useRef(profile);
  const stateRef = useRef(bot3dState);
  const analysisRef = useRef(analysis);
  const speakingRef = useRef(isSpeaking);
  const drawerOpenRef = useRef(drawerOpen);
  const presetTransitionRef = useRef<{
    active: boolean;
    preset: CameraPreset;
  }>({ active: true, preset: cameraPreset });

  const sceneHooksRef = useRef<{
    applyTheme?: (theme: OfficeTheme) => void;
    refreshMonitors?: () => void;
    refreshProfile?: () => void;
  }>({});

  profileRef.current = profile;
  stateRef.current = bot3dState;
  analysisRef.current = analysis;
  speakingRef.current = isSpeaking;
  drawerOpenRef.current = drawerOpen;

  useEffect(() => {
    presetTransitionRef.current = { active: true, preset: cameraPreset };
  }, [cameraPreset, drawerOpen]);

  useEffect(() => {
    sceneHooksRef.current.applyTheme?.(profile.officeTheme);
    sceneHooksRef.current.refreshProfile?.();
  }, [profile]);

  useEffect(() => {
    sceneHooksRef.current.refreshMonitors?.();
  }, [analysis, profile.accentColor]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      try {
        const probe = document.createElement('canvas').getContext('webgl2');
        if (!probe) return true;
        const ext = probe.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
        const gpu = String(probe.getParameter(param));
        probe.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      preserveDrawingBuffer: true,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(
      isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2)
    );
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    const initW = container.clientWidth || window.innerWidth;
    const initH = container.clientHeight || window.innerHeight;
    renderer.setSize(initW, initH);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';

    container.appendChild(renderer.domElement);

    const onContextLost = (e: Event) => {
      e.preventDefault();
      setContextLost(true);
    };
    const onContextRestored = () => {
      setContextLost(false);
    };
    renderer.domElement.addEventListener('webglcontextlost', onContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', onContextRestored);

    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xeef2f6);
    scene.fog = new THREE.FogExp2(0xeef2f6, 0.042);

    let envTex: THREE.Texture | null = null;
    try {
      const pmremGenerator = new THREE.PMREMGenerator(renderer);
      envTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
      scene.environment = envTex;
      pmremGenerator.dispose();
    } catch {
      // Fallback gracefully to direct scene lighting if PMREM is unavailable
    }

    const camera = new THREE.PerspectiveCamera(44, initW / initH, 0.1, 80);
    const initialDrawerShiftX = drawerOpenRef.current ? 1.15 : 0;
    camera.position.set(
      CAMERA_TARGETS.desk.pos[0] + initialDrawerShiftX,
      CAMERA_TARGETS.desk.pos[1],
      CAMERA_TARGETS.desk.pos[2]
    );

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(
      CAMERA_TARGETS.desk.target[0] + initialDrawerShiftX,
      CAMERA_TARGETS.desk.target[1],
      CAMERA_TARGETS.desk.target[2]
    );
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.07;
    controls.maxPolarAngle = Math.PI * 0.48;
    controls.minDistance = 2.0;
    controls.maxDistance = 12.0;
    controls.addEventListener('start', () => {
      presetTransitionRef.current.active = false;
    });

    // Studio 3-point + cool HemisphereLight fill
    const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x475569, 0.85);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff7ed, 1.9);
    keyLight.position.set(4.5, 7.5, 5.2);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 22;
    keyLight.shadow.camera.left = -6;
    keyLight.shadow.camera.right = 6;
    keyLight.shadow.camera.top = 6;
    keyLight.shadow.camera.bottom = -6;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x93c5fd, 0.9);
    rimLight.position.set(-4.5, 4.0, -4.5);
    scene.add(rimLight);

    const beaconPointLight = new THREE.PointLight(0x3b82f6, 3.2, 8, 2);
    beaconPointLight.position.set(-2.35, 2.15, -1.1);
    scene.add(beaconPointLight);

    // Track geometries/materials for clean unmount disposal
    const disposables: Array<{ dispose: () => void }> = envTex ? [envTex] : [];
    const track = <T extends { dispose: () => void }>(d: T): T => {
      disposables.push(d);
      return d;
    };

    // Floor & Grid
    const initialFloor = createFloorTextures(
      profileRef.current.officeTheme,
      maxAnisotropy
    );
    track(initialFloor.map);
    track(initialFloor.bumpMap);

    const floorMat = track(
      new THREE.MeshStandardMaterial({
        color: 0xffffff,
        map: initialFloor.map,
        bumpMap: initialFloor.bumpMap,
        bumpScale: 0.015,
        roughness: 0.72,
        metalness: 0.08,
      })
    );
    const floorMesh = new THREE.Mesh(
      track(new THREE.PlaneGeometry(24, 24)),
      floorMat
    );
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.receiveShadow = true;
    scene.add(floorMesh);

    // Glass-walled Operations Backdrop Partition
    const partitionGroup = new THREE.Group();
    partitionGroup.position.set(0, 0, -2.6);
    scene.add(partitionGroup);

    const mullionMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        roughness: 0.25,
        metalness: 0.85,
      })
    );
    const glassMat = track(
      new THREE.MeshPhysicalMaterial({
        color: 0xe0f2fe,
        roughness: 0.08,
        metalness: 0.0,
        transmission: isSoftwareGl ? 0 : 0.72,
        transparent: true,
        opacity: isSoftwareGl ? 0.32 : 1,
        depthWrite: false,
      })
    );

    const glassPane = new THREE.Mesh(
      track(new THREE.BoxGeometry(8.4, 3.2, 0.05)),
      glassMat
    );
    glassPane.position.y = 1.6;
    glassPane.renderOrder = 2;
    partitionGroup.add(glassPane);

    for (let x = -4.2; x <= 4.21; x += 2.1) {
      const post = new THREE.Mesh(
        track(new THREE.BoxGeometry(0.09, 3.3, 0.11)),
        mullionMat
      );
      post.position.set(x, 1.65, 0);
      post.castShadow = true;
      partitionGroup.add(post);
    }
    const headerBeam = new THREE.Mesh(
      track(new THREE.BoxGeometry(8.6, 0.12, 0.14)),
      mullionMat
    );
    headerBeam.position.set(0, 3.25, 0);
    partitionGroup.add(headerBeam);

    // Operations & Barcode Scanner Desk (Composite 6-part Group)
    const deskGroup = new THREE.Group();
    deskGroup.position.set(-1.35, 0, 0.95);
    deskGroup.rotation.y = 0.24;
    scene.add(deskGroup);

    const deskTopMat = track(
      new THREE.MeshStandardMaterial({
        color: 0xf8fafc,
        roughness: 0.42,
        metalness: 0.08,
      })
    );
    const deskLegMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        roughness: 0.28,
        metalness: 0.82,
      })
    );

    const deskTop = new THREE.Mesh(
      track(new THREE.BoxGeometry(1.7, 0.07, 0.82)),
      deskTopMat
    );
    deskTop.position.y = 0.86;
    deskTop.castShadow = true;
    deskTop.receiveShadow = true;
    deskGroup.add(deskTop);

    for (const lx of [-0.75, 0.75]) {
      for (const lz of [-0.32, 0.32]) {
        const leg = new THREE.Mesh(
          track(new THREE.CylinderGeometry(0.03, 0.028, 0.84, 12)),
          deskLegMat
        );
        leg.position.set(lx, 0.42, lz);
        leg.castShadow = true;
        deskGroup.add(leg);
      }
    }

    // Barcode Scanner Cradle + Laser Plane
    const scannerBase = new THREE.Mesh(
      track(new THREE.CylinderGeometry(0.08, 0.11, 0.04, 16)),
      deskLegMat
    );
    scannerBase.position.set(0.45, 0.915, 0.1);
    deskGroup.add(scannerBase);

    const scannerHead = new THREE.Mesh(
      track(new THREE.BoxGeometry(0.09, 0.18, 0.12)),
      deskLegMat
    );
    scannerHead.position.set(0.45, 1.06, 0.1);
    scannerHead.rotation.x = 0.35;
    deskGroup.add(scannerHead);

    const scanBeamMat = track(
      new THREE.MeshBasicMaterial({
        color: 0xef4444,
        transparent: true,
        opacity: 0.42,
        side: THREE.DoubleSide,
      })
    );
    const scanBeam = new THREE.Mesh(
      track(new THREE.PlaneGeometry(0.28, 0.18)),
      scanBeamMat
    );
    scanBeam.position.set(0.45, 0.99, 0.22);
    scanBeam.rotation.x = Math.PI / 3;
    deskGroup.add(scanBeam);

    // Status Beacon Pedestal
    const beaconPedestal = new THREE.Mesh(
      track(new THREE.CylinderGeometry(0.14, 0.19, 1.85, 20)),
      mullionMat
    );
    beaconPedestal.position.set(-2.35, 0.925, -1.1);
    beaconPedestal.castShadow = true;
    scene.add(beaconPedestal);

    const beaconDomeMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x3b82f6,
        emissive: 0x3b82f6,
        emissiveIntensity: 1.5,
        roughness: 0.15,
      })
    );
    const beaconDome = new THREE.Mesh(
      track(new THREE.SphereGeometry(0.16, 20, 16)),
      beaconDomeMat
    );
    beaconDome.position.set(-2.35, 1.98, -1.1);
    scene.add(beaconDome);

    // Smart Stockroom Shelving Rack (Right-Back Zone)
    const rackGroup = new THREE.Group();
    rackGroup.position.set(2.45, 0, -1.55);
    rackGroup.rotation.y = -0.34;
    scene.add(rackGroup);

    for (const rx of [-0.9, 0.9]) {
      for (const rz of [-0.32, 0.32]) {
        const post = new THREE.Mesh(
          track(new THREE.BoxGeometry(0.06, 2.2, 0.06)),
          mullionMat
        );
        post.position.set(rx, 1.1, rz);
        post.castShadow = true;
        rackGroup.add(post);
      }
    }

    const shelfMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x475569,
        roughness: 0.48,
        metalness: 0.55,
      })
    );
    for (const sy of [0.22, 0.95, 1.68]) {
      const shelf = new THREE.Mesh(
        track(new THREE.BoxGeometry(1.88, 0.05, 0.7)),
        shelfMat
      );
      shelf.position.set(0, sy, 0);
      shelf.receiveShadow = true;
      rackGroup.add(shelf);
    }

    const boxGeo = track(new THREE.BoxGeometry(0.38, 0.34, 0.38));
    const stockBoxes: Array<{ mesh: THREE.Mesh; mat: THREE.MeshStandardMaterial }> = [];
    const boxSlots: Array<[number, number, number]> = [
      [-0.55, 0.42, 0],
      [0.0, 0.42, 0],
      [0.55, 0.42, 0],
      [-0.55, 1.15, 0],
      [0.0, 1.15, 0],
      [0.55, 1.15, 0],
      [-0.3, 1.88, 0],
      [0.35, 1.88, 0],
    ];
    for (const [bx, by, bz] of boxSlots) {
      const mat = track(
        new THREE.MeshStandardMaterial({
          color: 0x10b981,
          roughness: 0.68,
          metalness: 0.05,
        })
      );
      const box = new THREE.Mesh(boxGeo, mat);
      box.position.set(bx, by, bz);
      box.castShadow = true;
      rackGroup.add(box);
      stockBoxes.push({ mesh: box, mat });
    }

    // 3 Floating Holographic Monitors
    type ScreenKey = 'sales_chart' | 'inventory_grid' | 'error_diff_terminal';
    const monitorEntries: Array<{
      key: ScreenKey;
      group: THREE.Group;
      baseY: number;
      ctx: CanvasRenderingContext2D;
      tex: THREE.CanvasTexture;
    }> = [];

    const monitorConfigs: Array<{
      key: ScreenKey;
      pos: [number, number, number];
      rotY: number;
    }> = [
      { key: 'sales_chart', pos: [-1.45, 2.35, -0.8], rotY: 0.35 },
      { key: 'inventory_grid', pos: [0.05, 2.65, -1.25], rotY: 0.0 },
      { key: 'error_diff_terminal', pos: [1.52, 2.28, -0.72], rotY: -0.38 },
    ];

    for (const cfg of monitorConfigs) {
      const mGroup = new THREE.Group();
      mGroup.position.set(...cfg.pos);
      mGroup.rotation.y = cfg.rotY;
      scene.add(mGroup);

      const frame = new THREE.Mesh(
        track(new THREE.BoxGeometry(1.16, 0.72, 0.04)),
        mullionMat
      );
      mGroup.add(frame);

      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 320;
      const ctx = canvas.getContext('2d')!;
      drawMonitorTexture(ctx, cfg.key, analysisRef.current, profileRef.current.accentColor);
      const tex = track(new THREE.CanvasTexture(canvas));
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = maxAnisotropy;

      const screenMesh = new THREE.Mesh(
        track(new THREE.PlaneGeometry(1.08, 0.64)),
        track(
          new THREE.MeshBasicMaterial({
            map: tex,
          })
        )
      );
      screenMesh.position.z = 0.025;
      mGroup.add(screenMesh);

      monitorEntries.push({
        key: cfg.key,
        group: mGroup,
        baseY: cfg.pos[1],
        ctx,
        tex,
      });
    }

    // Hero Character: PemBot 3D
    const pemBot: PemBotRig = createPemBot(profileRef.current, maxAnisotropy);
    pemBot.root.position.set(0, 0, 0);
    scene.add(pemBot.root);

    // Helper hooks for React prop sync without recreating scene
    const applyTheme = (theme: OfficeTheme) => {
      if (theme === 'cyberpunk_night') {
        scene.background = new THREE.Color(0x090d1a);
        scene.fog = new THREE.FogExp2(0x090d1a, 0.052);
        hemiLight.color.setHex(0x38bdf8);
        hemiLight.groundColor.setHex(0x0f172a);
        hemiLight.intensity = 0.7;
        keyLight.color.setHex(0xe0f2fe);
        keyLight.intensity = 1.45;
        deskTopMat.color.setHex(0x1e293b);
      } else if (theme === 'minimalist_warehouse') {
        scene.background = new THREE.Color(0xdbe2ea);
        scene.fog = new THREE.FogExp2(0xdbe2ea, 0.036);
        hemiLight.color.setHex(0xf1f5f9);
        hemiLight.groundColor.setHex(0x64748b);
        hemiLight.intensity = 0.9;
        keyLight.color.setHex(0xfffbeb);
        keyLight.intensity = 2.0;
        deskTopMat.color.setHex(0xe2e8f0);
      } else {
        scene.background = new THREE.Color(0xeef2f6);
        scene.fog = new THREE.FogExp2(0xeef2f6, 0.04);
        hemiLight.color.setHex(0xdbeafe);
        hemiLight.groundColor.setHex(0x475569);
        hemiLight.intensity = 0.85;
        keyLight.color.setHex(0xfff7ed);
        keyLight.intensity = 1.9;
        deskTopMat.color.setHex(0xf8fafc);
      }

      const nextFloor = createFloorTextures(theme, maxAnisotropy);
      floorMat.map?.dispose();
      floorMat.bumpMap?.dispose();
      floorMat.map = nextFloor.map;
      floorMat.bumpMap = nextFloor.bumpMap;
      floorMat.needsUpdate = true;
    };

    const refreshMonitors = () => {
      for (const entry of monitorEntries) {
        drawMonitorTexture(
          entry.ctx,
          entry.key,
          analysisRef.current,
          profileRef.current.accentColor
        );
        entry.tex.needsUpdate = true;
      }

      const invRows = analysisRef.current?.inventoryHealth ?? [];
      stockBoxes.forEach((box, idx) => {
        const item = invRows[idx];
        if (!item) {
          box.mat.color.setHex(0x94a3b8);
          return;
        }
        if (item.status === 'CRITICAL') box.mat.color.setHex(0xef4444);
        else if (item.status === 'LOW_STOCK') box.mat.color.setHex(0xf59e0b);
        else if (item.status === 'OVERSTOCK') box.mat.color.setHex(0x6366f1);
        else box.mat.color.setHex(0x10b981);
      });
    };

    sceneHooksRef.current = {
      applyTheme,
      refreshMonitors,
      refreshProfile: () => pemBot.updateProfile(profileRef.current, maxAnisotropy),
    };

    applyTheme(profileRef.current.officeTheme);
    refreshMonitors();

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const handleResize = () => {
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);
    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    let prevTime = performance.now();
    let elapsed = 0;
    let rafId = 0;
    let timerId = 0;
    let disposed = false;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync =
        typeof gl.fenceSync === 'function'
          ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0)
          : null;
      gl.flush();
      const poll = () => {
        if (disposed) {
          if (sync) gl.deleteSync(sync);
          return;
        }
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          timerId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          timerId = window.setTimeout(cb, 80);
        }
      };
      timerId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (disposed) return;
      const now = performance.now();
      const delta = Math.min(Math.max((now - prevTime) / 1000, 0.001), 0.1);
      prevTime = now;
      elapsed += delta;

      const curState = stateRef.current;
      const curProfile = profileRef.current;

      // Damped camera preset transitions + shift target slightly right when drawer is open
      if (presetTransitionRef.current.active) {
        const cfg = CAMERA_TARGETS[presetTransitionRef.current.preset];
        const drawerShiftX = drawerOpenRef.current ? 1.15 : 0;
        _desiredCamPos.set(cfg.pos[0] + drawerShiftX, cfg.pos[1], cfg.pos[2]);
        _desiredTarget.set(
          cfg.target[0] + drawerShiftX,
          cfg.target[1],
          cfg.target[2]
        );
        const alpha = 1 - Math.exp(-5.5 * delta);
        camera.position.lerp(_desiredCamPos, alpha);
        controls.target.lerp(_desiredTarget, alpha);
        if (camera.position.distanceTo(_desiredCamPos) < 0.02) {
          presetTransitionRef.current.active = false;
        }
      }

      controls.update();

      // Update status beacon lighting
      if (curState.office_lighting === 'celebration_gold') {
        _targetBeaconColor.setHex(0xfbbf24);
      } else if (curState.office_lighting === 'caution_amber') {
        _targetBeaconColor.setHex(0xf59e0b);
      } else if (curState.office_lighting === 'quarantine_red') {
        _targetBeaconColor.setHex(0xef4444);
      } else {
        _targetBeaconColor.setHex(0x3b82f6);
      }
      beaconDomeMat.color.lerp(_targetBeaconColor, 1 - Math.exp(-6 * delta));
      beaconDomeMat.emissive.lerp(_targetBeaconColor, 1 - Math.exp(-6 * delta));
      beaconPointLight.color.lerp(_targetBeaconColor, 1 - Math.exp(-6 * delta));

      // Gentle float on holographic monitors
      monitorEntries.forEach((m, idx) => {
        m.group.position.y = m.baseY + Math.sin(elapsed * 1.4 + idx * 1.3) * 0.04;
      });

      pemBot.updateFrame(
        elapsed,
        delta,
        curState.animation,
        curState.expression,
        curProfile.accentColor,
        speakingRef.current
      );

      renderer.render(scene, camera);
      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        rafId = requestAnimationFrame(tick);
      }
    }

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(rafId);
      clearTimeout(timerId);
      resizeObserver.disconnect();
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
      renderer.domElement.removeEventListener(
        'webglcontextrestored',
        onContextRestored
      );
      controls.dispose();
      pemBot.dispose();
      for (const item of disposables) {
        item.dispose();
      }
      floorMat.map?.dispose();
      floorMat.bumpMap?.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div className="relative h-full w-full overflow-hidden">
      <div
        ref={mountRef}
        data-testid="three-office-canvas"
        className="h-full w-full"
      />
      {contextLost && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900/90 text-slate-100">
          <p className="text-sm font-medium">
            3D viewport paused — restoring graphics context...
          </p>
        </div>
      )}
    </div>
  );
};
