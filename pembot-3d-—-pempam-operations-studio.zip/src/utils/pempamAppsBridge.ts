import {
  OperationalBatchInput,
  RawInventoryRecord,
  RawReceiptRecord,
} from '../types/operations';
import { getManilaTimestamp, redactSensitiveText } from './operationsEngine';

export const GLONEXT_STORAGE_KEY = 'pempam_state_v1';
export const REPAIR_RECEIPTS_STORAGE_KEY = 'pempam_receipts';
export const REPAIR_NEXT_NO_STORAGE_KEY = 'pempam_receipt_no';
export const GLONEXT_BACKUP_KEY = 'pempam_backup_before_fix';

export interface RepairReceiptEntry {
  no: string;
  date: string;
  time?: string;
  clientName: string;
  clientAddress?: string;
  clientMobile?: string;
  printerName?: string;
  printerModel?: string;
  printerSerial?: string;
  problemDesc?: string;
  hasPowerCord?: boolean;
  hasUsbCable?: boolean;
  totalService?: string | number;
  totalParts?: string | number;
  overallTotal?: string | number;
  status: 'Pending' | 'Claimed' | 'Disposed' | string;
}

export interface GloNextProduct {
  id: string;
  name: string;
  sku: string;
  category: string;
  cost: number;
  retail: number;
  wholesale?: number;
  member?: number;
  stock: number;
  lowStock: number;
  archived?: boolean;
}

export interface GloNextSaleLine {
  productId: string;
  name: string;
  qty: number;
  price: number;
  lineTotal: number;
  cost?: number;
}

export interface GloNextSale {
  id: string;
  date: string;
  items: GloNextSaleLine[];
  subtotal: number;
  discount: number;
  total: number;
  paymentMethod?: string;
  customerId?: string;
  cashier?: string;
  status: 'completed' | 'refunded' | string;
}

export interface GloNextState {
  company?: {
    name?: string;
    currency?: string;
  };
  categories?: string[];
  products?: GloNextProduct[];
  customers?: Array<{ id: string; name: string; type?: string; totalSpent?: number }>;
  suppliers?: Array<{ id: string; name: string }>;
  sales?: GloNextSale[];
  stockMovements?: Array<{
    id: string;
    date: string;
    productId: string;
    type: string;
    qty: number;
    note?: string;
  }>;
  activityLog?: Array<{
    id: string;
    date: string;
    user: string;
    role: string;
    action: string;
  }>;
}

export interface LivePempamSnapshot {
  hasGloNextData: boolean;
  hasRepairData: boolean;
  gloNextState: GloNextState | null;
  repairReceipts: RepairReceiptEntry[];
  nextRepairReceiptNo: number;
  metrics: {
    posProductsCount: number;
    posLowStockCount: number;
    posCompletedSalesCount: number;
    posCustomersCount: number;
    repairTotalCount: number;
    repairPendingCount: number;
    repairClaimedCount: number;
    repairDisposedCount: number;
    repairOverdue30dCount: number;
    repairOverdue90dCount: number;
    repairPendingValuePhp: number;
  };
}

export function readLivePempamStorage(
  storage: Pick<Storage, 'getItem'> | null | undefined =
    typeof window !== 'undefined' ? window.localStorage : null,
  referenceNow: Date = new Date()
): LivePempamSnapshot {
  let gloNextState: GloNextState | null = null;
  let repairReceipts: RepairReceiptEntry[] = [];
  let nextRepairReceiptNo = 1189;

  if (storage) {
    try {
      const rawPos = storage.getItem(GLONEXT_STORAGE_KEY);
      if (rawPos) {
        const parsed = JSON.parse(rawPos);
        if (parsed && typeof parsed === 'object') {
          gloNextState = parsed as GloNextState;
        }
      }
    } catch {
      gloNextState = null;
    }

    try {
      const rawRepairs = storage.getItem(REPAIR_RECEIPTS_STORAGE_KEY);
      if (rawRepairs) {
        const parsed = JSON.parse(rawRepairs);
        if (Array.isArray(parsed)) {
          repairReceipts = parsed as RepairReceiptEntry[];
        }
      }
    } catch {
      repairReceipts = [];
    }

    try {
      const rawNo = storage.getItem(REPAIR_NEXT_NO_STORAGE_KEY);
      if (rawNo) {
        const num = parseInt(rawNo, 10);
        if (Number.isFinite(num) && num > 0) {
          nextRepairReceiptNo = num;
        }
      }
    } catch {
      // keep default
    }
  }

  const products = (gloNextState?.products ?? []).filter((p) => !p.archived);
  const completedSales = (gloNextState?.sales ?? []).filter(
    (s) => s.status === 'completed'
  );
  const lowStockCount = products.filter(
    (p) => (Number(p.stock) || 0) <= (Number(p.lowStock) || 0)
  ).length;

  let pendingCount = 0;
  let claimedCount = 0;
  let disposedCount = 0;
  let overdue30dCount = 0;
  let overdue90dCount = 0;
  let pendingValuePhp = 0;

  for (const r of repairReceipts) {
    const status = String(r.status || 'Pending').toLowerCase();
    const total = Number(r.overallTotal) || 0;
    if (status === 'claimed') {
      claimedCount += 1;
    } else if (status === 'disposed') {
      disposedCount += 1;
    } else {
      pendingCount += 1;
      pendingValuePhp += total;
      const d = new Date(r.date);
      if (!Number.isNaN(d.getTime())) {
        const ageDays = Math.floor(
          (referenceNow.getTime() - d.getTime()) / 86_400_000
        );
        if (ageDays > 90) {
          overdue90dCount += 1;
        } else if (ageDays > 30) {
          overdue30dCount += 1;
        }
      }
    }
  }

  return {
    hasGloNextData: Boolean(gloNextState),
    hasRepairData: repairReceipts.length > 0,
    gloNextState,
    repairReceipts,
    nextRepairReceiptNo,
    metrics: {
      posProductsCount: products.length,
      posLowStockCount: lowStockCount,
      posCompletedSalesCount: completedSales.length,
      posCustomersCount: (gloNextState?.customers ?? []).length,
      repairTotalCount: repairReceipts.length,
      repairPendingCount: pendingCount,
      repairClaimedCount: claimedCount,
      repairDisposedCount: disposedCount,
      repairOverdue30dCount: overdue30dCount,
      repairOverdue90dCount: overdue90dCount,
      repairPendingValuePhp: Number(pendingValuePhp.toFixed(2)),
    },
  };
}

export function buildLivePempamBatch(
  snapshot: LivePempamSnapshot,
  referenceNow: Date = new Date()
): OperationalBatchInput {
  const receipts: RawReceiptRecord[] = [];
  const inventory: RawInventoryRecord[] = [];
  const soldBySku = new Map<string, number>();

  const glo = snapshot.gloNextState;
  const prodById = new Map<string, GloNextProduct>();
  for (const p of glo?.products ?? []) {
    prodById.set(p.id, p);
  }

  for (const sale of glo?.sales ?? []) {
    if (sale.status === 'refunded') continue;
    const items = (sale.items ?? []).map((it) => {
      const prod = prodById.get(it.productId);
      const sku = prod?.sku || it.productId || 'POS-ITEM';
      soldBySku.set(sku, (soldBySku.get(sku) ?? 0) + (Number(it.qty) || 0));
      return {
        sku,
        name: redactSensitiveText(it.name || prod?.name || 'POS Item').sanitized,
        qty: Number(it.qty) || 0,
        unitPricePhp: Number(it.price) || 0,
        unitCostPhp:
          typeof it.cost === 'number'
            ? it.cost
            : typeof prod?.cost === 'number'
              ? prod.cost
              : undefined,
      };
    });

    receipts.push({
      receiptId: `POS-${String(sale.id).slice(-8).toUpperCase()}`,
      date: sale.date || referenceNow.toISOString(),
      paymentMethod: sale.paymentMethod || 'Cash',
      discountPhp: Number(sale.discount) || 0,
      reportedTotalPhp:
        typeof sale.total === 'number' ? Number(sale.total) : null,
      customerNote: sale.cashier
        ? redactSensitiveText(`GloNext Cashier: ${sale.cashier}`).sanitized
        : undefined,
      items,
    });
  }

  for (const rep of snapshot.repairReceipts) {
    const svc = Number(rep.totalService) || 0;
    const parts = Number(rep.totalParts) || 0;
    const overall = Number(rep.overallTotal) || svc + parts;
    const noteParts = [
      `Repair Status: ${rep.status || 'Pending'}`,
      rep.printerName ? `Printer: ${rep.printerName}` : '',
      rep.printerModel ? `Model: ${rep.printerModel}` : '',
    ]
      .filter(Boolean)
      .join(' · ');

    const lineItems = [];
    if (svc > 0) {
      lineItems.push({
        sku: 'SVC-REPAIR',
        name: 'Technical Repair Service',
        qty: 1,
        unitPricePhp: svc,
      });
    }
    if (parts > 0) {
      lineItems.push({
        sku: 'PARTS-REPAIR',
        name: 'Printer Replacement Parts',
        qty: 1,
        unitPricePhp: parts,
      });
    }
    if (lineItems.length === 0) {
      lineItems.push({
        sku: 'SVC-DIAGNOSTIC',
        name: 'Repair & Service Bench Ticket',
        qty: 1,
        unitPricePhp: overall,
        promoTag: overall === 0 ? 'DIAGNOSTIC' : undefined,
      });
    }

    receipts.push({
      receiptId: `REP-${rep.no}`,
      date: rep.date
        ? `${rep.date}T${rep.time || '09:00'}:00+08:00`
        : referenceNow.toISOString(),
      paymentMethod: rep.status === 'Claimed' ? 'Cash' : 'Pending Claim',
      discountPhp: 0,
      reportedTotalPhp: overall,
      customerNote: redactSensitiveText(noteParts).sanitized,
      items: lineItems,
    });
  }

  for (const prod of glo?.products ?? []) {
    if (prod.archived) continue;
    const sku = prod.sku || prod.id;
    const sold = soldBySku.get(sku) ?? 0;
    const actual = Number(prod.stock) || 0;
    inventory.push({
      sku,
      name: redactSensitiveText(prod.name).sanitized,
      category: prod.category || 'General',
      beginningStock: Math.max(0, actual + sold),
      restocks: 0,
      unitsSoldReported: sold,
      actualStock: actual,
      reorderThreshold: Math.max(1, Number(prod.lowStock) || 5),
      unitCostPhp: Number(prod.cost) || 0,
      unitPricePhp: Number(prod.retail) || 0,
      periodDays: 14,
    });
  }

  return {
    batchTitle: 'Live Pempam GloNext POS + Repair Desk Sync',
    periodDays: 14,
    receipts,
    inventory,
  };
}

export function applyRepairsToGloNextState(
  rawStateJson: string,
  repairedPayload: OperationalBatchInput
): string {
  const parsed = JSON.parse(rawStateJson) as GloNextState;
  const repairedStockBySku = new Map<string, number>();

  for (const inv of repairedPayload.inventory) {
    repairedStockBySku.set(inv.sku, Math.max(0, Math.round(inv.actualStock)));
  }

  if (Array.isArray(parsed.products)) {
    parsed.products = parsed.products.map((prod) => {
      const nextStock = repairedStockBySku.get(prod.sku);
      if (nextStock !== undefined) {
        return { ...prod, stock: nextStock };
      }
      return prod;
    });
  }

  if (!Array.isArray(parsed.activityLog)) {
    parsed.activityLog = [];
  }
  parsed.activityLog.unshift({
    id: `pembot-${Date.now()}`,
    date: new Date().toISOString(),
    user: 'PemBot 3D Agent',
    role: 'AI Operations',
    action: `CONFIRM FIX verified & synced repaired inventory counts at ${getManilaTimestamp()}.`,
  });

  return JSON.stringify(parsed);
}

export function writeRepairsToLiveStorage(
  storage: Pick<Storage, 'getItem' | 'setItem'> | null | undefined,
  repairedPayload: OperationalBatchInput
): { updatedGloNext: boolean; backupSaved: boolean } {
  if (!storage) {
    return { updatedGloNext: false, backupSaved: false };
  }
  const rawPos = storage.getItem(GLONEXT_STORAGE_KEY);
  if (!rawPos) {
    return { updatedGloNext: false, backupSaved: false };
  }
  storage.setItem(GLONEXT_BACKUP_KEY, rawPos);
  const nextJson = applyRepairsToGloNextState(rawPos, repairedPayload);
  storage.setItem(GLONEXT_STORAGE_KEY, nextJson);
  return { updatedGloNext: true, backupSaved: true };
}

export function buildLiveAppsContextSummary(snapshot: LivePempamSnapshot) {
  return {
    gloNextInitialized: snapshot.hasGloNextData,
    repairDeskInitialized: snapshot.hasRepairData,
    metrics: snapshot.metrics,
    pendingRepairTickets: snapshot.repairReceipts
      .filter((r) => String(r.status || 'Pending').toLowerCase() === 'pending')
      .slice(0, 8)
      .map((r) => ({
        no: r.no,
        date: r.date,
        printer: [r.printerName, r.printerModel].filter(Boolean).join(' '),
        totalPhp: Number(r.overallTotal) || 0,
        status: r.status,
      })),
  };
}
