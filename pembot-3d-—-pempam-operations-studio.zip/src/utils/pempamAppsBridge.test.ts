import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyRepairsToGloNextState,
  buildLiveAppsContextSummary,
  buildLivePempamBatch,
  GLONEXT_BACKUP_KEY,
  GLONEXT_STORAGE_KEY,
  REPAIR_NEXT_NO_STORAGE_KEY,
  REPAIR_RECEIPTS_STORAGE_KEY,
  readLivePempamStorage,
  writeRepairsToLiveStorage,
} from './pempamAppsBridge';
import { analyzeOperationsBatch, DEFAULT_BOT_PROFILE } from './operationsEngine';

function createMemoryStorage(initial: Record<string, string> = {}) {
  const map = new Map<string, string>(Object.entries(initial));
  return {
    getItem: (k: string) => map.get(k) ?? null,
    setItem: (k: string, v: string) => {
      map.set(k, v);
    },
  };
}

test('readLivePempamStorage & buildLivePempamBatch combine GloNext POS and Repair Receipts', () => {
  const mockPos = {
    company: { name: 'PEMPAM', currency: '₱' },
    products: [
      {
        id: 'p1',
        name: 'Epson 003 Black',
        sku: 'EPS-003-BLK',
        category: 'Ink & Toner',
        cost: 220,
        retail: 320,
        stock: 2,
        lowStock: 5,
        archived: false,
      },
      {
        id: 'p2',
        name: 'Brother TN-1000',
        sku: 'BRO-TN1000',
        category: 'Ink & Toner',
        cost: 1650,
        retail: 1950,
        stock: 0,
        lowStock: 4,
        archived: false,
      },
    ],
    customers: [{ id: 'c1', name: 'Maria Santos', type: 'member' }],
    sales: [
      {
        id: 'sale101',
        date: '2026-11-22T10:15:00+08:00',
        items: [
          {
            productId: 'p1',
            name: 'Epson 003 Black',
            qty: 2,
            price: 320,
            lineTotal: 640,
            cost: 220,
          },
        ],
        subtotal: 640,
        discount: 0,
        total: 640,
        paymentMethod: 'GCash',
        cashier: 'Cathy Cashier',
        status: 'completed',
      },
    ],
  };

  const mockRepairs = [
    {
      no: '001189',
      date: '2026-10-10',
      time: '14:00',
      clientName: 'Juan',
      printerName: 'Epson',
      printerModel: 'L3210',
      totalService: '500.00',
      totalParts: '350.00',
      overallTotal: '850.00',
      status: 'Pending',
    },
    {
      no: '001188',
      date: '2026-11-21',
      time: '11:00',
      clientName: 'Liza',
      printerName: 'Brother',
      printerModel: 'HL-1210W',
      totalService: '400.00',
      totalParts: '0.00',
      overallTotal: '400.00',
      status: 'Claimed',
    },
  ];

  const storage = createMemoryStorage({
    [GLONEXT_STORAGE_KEY]: JSON.stringify(mockPos),
    [REPAIR_RECEIPTS_STORAGE_KEY]: JSON.stringify(mockRepairs),
    [REPAIR_NEXT_NO_STORAGE_KEY]: '1190',
  });

  const snapshot = readLivePempamStorage(
    storage,
    new Date('2026-11-23T09:00:00+08:00')
  );

  assert.equal(snapshot.hasGloNextData, true);
  assert.equal(snapshot.hasRepairData, true);
  assert.equal(snapshot.metrics.posProductsCount, 2);
  assert.equal(snapshot.metrics.posLowStockCount, 2);
  assert.equal(snapshot.metrics.repairPendingCount, 1);
  assert.equal(snapshot.metrics.repairOverdue30dCount, 1);
  assert.equal(snapshot.metrics.repairPendingValuePhp, 850);
  assert.equal(snapshot.nextRepairReceiptNo, 1190);

  const batch = buildLivePempamBatch(snapshot);
  assert.equal(batch.receipts.length, 3);
  assert.equal(batch.inventory.length, 2);

  const result = analyzeOperationsBatch(batch, DEFAULT_BOT_PROFILE, {
    confirmFix: false,
  });
  assert.equal(result.salesSummary.netRevenuePhp, 1890);
  assert.equal(result.inventoryHealth.length, 2);

  const ctx = buildLiveAppsContextSummary(snapshot);
  assert.equal(ctx.pendingRepairTickets.length, 1);
  assert.equal(ctx.pendingRepairTickets[0].no, '001189');
});

test('writeRepairsToLiveStorage saves backup and logs CONFIRM FIX in GloNext activityLog', () => {
  const initialPos = {
    products: [
      {
        id: 'p1',
        name: 'Epson 003 Black',
        sku: 'EPS-003-BLK',
        category: 'Ink',
        cost: 200,
        retail: 300,
        stock: -3,
        lowStock: 5,
      },
    ],
    activityLog: [],
  };

  const storage = createMemoryStorage({
    [GLONEXT_STORAGE_KEY]: JSON.stringify(initialPos),
  });

  const repairedPayload = {
    batchTitle: 'Live Sync',
    receipts: [],
    inventory: [
      {
        sku: 'EPS-003-BLK',
        name: 'Epson 003 Black',
        category: 'Ink',
        beginningStock: 10,
        restocks: 0,
        actualStock: 7,
      },
    ],
  };

  const writeRes = writeRepairsToLiveStorage(storage, repairedPayload);
  assert.equal(writeRes.backupSaved, true);
  assert.equal(writeRes.updatedGloNext, true);
  assert.ok(storage.getItem(GLONEXT_BACKUP_KEY));

  const updated = JSON.parse(storage.getItem(GLONEXT_STORAGE_KEY)!);
  assert.equal(updated.products[0].stock, 7);
  assert.equal(updated.activityLog.length, 1);
  assert.match(updated.activityLog[0].action, /CONFIRM FIX/);

  // Direct pure helper check
  const nextRaw = applyRepairsToGloNextState(
    JSON.stringify(initialPos),
    repairedPayload
  );
  assert.equal(JSON.parse(nextRaw).products[0].stock, 7);
});
