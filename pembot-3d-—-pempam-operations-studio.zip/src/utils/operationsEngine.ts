import {
  AuditChangeLogEntry,
  Bot3DState,
  BotCustomizationProfile,
  EntityNormalizationSuggestion,
  InventoryHealthRow,
  OperationalAnalysisResult,
  OperationalBatchInput,
  PaymentSplitRow,
  ProductPerformanceRow,
  ProposedFixRecord,
  QuarantineRecord,
  RawInventoryRecord,
  RawReceiptRecord,
  StockStatus,
} from '../types/operations';

export const DEFAULT_BOT_PROFILE: BotCustomizationProfile = {
  botName: 'PemBot 3D',
  companyName: 'Pempam',
  officeTheme: 'daylight_studio',
  outfitStyle: 'standard_chassis',
  accentColor: '#2563EB',
  personality: 'friendly_coworker',
};

const SECRET_PATTERNS: RegExp[] = [
  /\bsk_(?:live|test)_[A-Za-z0-9]{10,}\b/g,
  /\bAIza[0-9A-Za-z_-]{20,}\b/g,
  /\bghp_[A-Za-z0-9]{20,}\b/g,
  /\bBearer\s+[A-Za-z0-9\-._~+/]+=*/gi,
  /\b(?:password|passwd|secret|api_key|apikey|token)\s*[:=]\s*["']?[^\s"',;]+["']?/gi,
  /\bpostgres(?:ql)?:\/\/[^\s"']+/gi,
];

const INJECTION_PATTERNS: RegExp[] = [
  /ignore\s+(?:all\s+)?previous\s+instructions/i,
  /system\s+override/i,
  /delete\s+all\s+(?:stock|records|tables|files)/i,
  /reveal\s+(?:system\s+prompt|api\s+key|secrets)/i,
  /drop\s+table/i,
];

export function formatPhp(amount: number): string {
  return `₱${amount.toLocaleString('en-PH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function getManilaTimestamp(date: Date = new Date()): string {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Manila',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
  return `${formatter.format(date).replace(', ', ' ')} PHT (UTC+8)`;
}

export function redactSensitiveText(input: string): {
  sanitized: string;
  redactedCount: number;
  injectionBlocked: boolean;
} {
  let sanitized = input;
  let redactedCount = 0;

  for (const regex of SECRET_PATTERNS) {
    sanitized = sanitized.replace(regex, () => {
      redactedCount += 1;
      return '[REDACTED]';
    });
  }

  let injectionBlocked = false;
  for (const pattern of INJECTION_PATTERNS) {
    if (pattern.test(sanitized)) {
      injectionBlocked = true;
      sanitized = sanitized.replace(
        new RegExp(pattern.source, 'gi'),
        '[BLOCKED_INJECTION_DIRECTIVE]'
      );
    }
  }

  return { sanitized, redactedCount, injectionBlocked };
}

export function canonicalizeProductName(
  rawName: string,
  rawSku?: string
): {
  canonicalSku: string;
  canonicalName: string;
} {
  const normalized = rawName.trim().toLowerCase().replace(/\s+/g, ' ');
  if (
    normalized === 'epson 003 blk' ||
    normalized === 'epson 003 black' ||
    normalized === 'epson003 black'
  ) {
    return { canonicalSku: 'EPS-003-BLK', canonicalName: 'Epson 003 Black' };
  }
  if (normalized === 'epson 003 cyn' || normalized === 'epson 003 cyan') {
    return { canonicalSku: 'EPS-003-CYN', canonicalName: 'Epson 003 Cyan' };
  }
  const cleanedSku = rawSku
    ?.trim()
    .toUpperCase()
    .replace(/[^A-Z0-9_-]+/g, '-')
    .replace(/^-|-$/g, '');
  const slug = rawName
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 24);
  return {
    canonicalSku: cleanedSku || slug || 'UNKNOWN-SKU',
    canonicalName: rawName.trim() || '[MISSING DATA — REVIEW REQUIRED]',
  };
}

export function parseCustomizationCommand(
  commandText: string,
  current: BotCustomizationProfile
): {
  matched: boolean;
  updated: BotCustomizationProfile;
  summary: string;
} {
  const text = commandText.trim();
  const lower = text.toLowerCase();
  const isCustomizeIntent =
    lower.startsWith('/customize') ||
    /\b(rename yourself|change your outfit|wear a|switch office|cyberpunk|daylight studio|warehouse mode|strict auditor|executive briefing|friendly co-?worker|accent color)\b/i.test(
      lower
    );

  if (!isCustomizeIntent) {
    return { matched: false, updated: current, summary: '' };
  }

  const next: BotCustomizationProfile = { ...current };
  const changes: string[] = [];

  const renameMatch =
    text.match(/rename\s+(?:yourself\s+)?(?:to|as)\s+["']?([A-Za-z0-9 _-]{2,30})["']?/i) ||
    text.match(/bot\s*name\s*[:=]\s*["']?([A-Za-z0-9 _-]{2,30})["']?/i);
  if (renameMatch?.[1]) {
    next.botName = renameMatch[1].trim();
    changes.push(`Bot Name → ${next.botName}`);
  }

  if (/barong/i.test(lower)) {
    next.outfitStyle = 'formal_barong';
    changes.push('Outfit → Formal Barong');
  } else if (/cyber\s*visor|goggles/i.test(lower)) {
    next.outfitStyle = 'cyber_visor';
    changes.push('Outfit → Cyber Visor');
  } else if (/executive\s*(?:slate|suit)/i.test(lower)) {
    next.outfitStyle = 'executive_slate';
    changes.push('Outfit → Executive Slate');
  } else if (/standard\s*chassis|default\s*outfit/i.test(lower)) {
    next.outfitStyle = 'standard_chassis';
    changes.push('Outfit → Standard Chassis');
  }

  if (/cyberpunk|night\s*shift|dark\s*mode/i.test(lower)) {
    next.officeTheme = 'cyberpunk_night';
    changes.push('Office Theme → Cyberpunk Night Shift');
  } else if (/warehouse|minimalist/i.test(lower)) {
    next.officeTheme = 'minimalist_warehouse';
    changes.push('Office Theme → Minimalist Warehouse');
  } else if (/daylight|studio/i.test(lower)) {
    next.officeTheme = 'daylight_studio';
    changes.push('Office Theme → Daylight Studio');
  }

  if (/strict\s*auditor/i.test(lower)) {
    next.personality = 'strict_auditor';
    changes.push('Voice Tone → Strict Auditor');
  } else if (/executive\s*briefing/i.test(lower)) {
    next.personality = 'executive_briefing';
    changes.push('Voice Tone → Executive Briefing');
  } else if (/friendly\s*co-?worker/i.test(lower)) {
    next.personality = 'friendly_coworker';
    changes.push('Voice Tone → Friendly Co-Worker');
  }

  const hexMatch = text.match(/#[0-9a-fA-F]{6}\b/);
  if (hexMatch) {
    next.accentColor = hexMatch[0].toUpperCase();
    changes.push(`Accent Color → ${next.accentColor}`);
  } else if (/\bgold\b|\bamber\b/i.test(lower)) {
    next.accentColor = '#D97706';
    changes.push('Accent Color → Amber Gold');
  } else if (/\bemerald\b|\bgreen\b/i.test(lower)) {
    next.accentColor = '#059669';
    changes.push('Accent Color → Emerald');
  } else if (/\bcyan\b|\bteal\b/i.test(lower)) {
    next.accentColor = '#0891B2';
    changes.push('Accent Color → Cyan');
  }

  if (changes.length === 0) {
    return { matched: false, updated: current, summary: '' };
  }

  return {
    matched: true,
    updated: next,
    summary: `Applied customization: ${changes.join(' · ')}`,
  };
}

export function parseRawInputToBatch(rawInput: string): {
  batch: OperationalBatchInput | null;
  format: 'json' | 'csv' | 'text' | 'pos_log';
  parseError?: string;
} {
  const trimmed = rawInput.trim();
  if (!trimmed) {
    return { batch: null, format: 'text', parseError: 'Input is empty.' };
  }

  if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) {
        return {
          batch: {
            batchTitle: 'Uploaded JSON Receipts Batch',
            periodDays: 7,
            receipts: parsed as RawReceiptRecord[],
            inventory: [],
          },
          format: 'json',
        };
      }
      if (parsed && typeof parsed === 'object') {
        const receipts = Array.isArray(parsed.receipts) ? parsed.receipts : [];
        const inventory = Array.isArray(parsed.inventory) ? parsed.inventory : [];
        return {
          batch: {
            batchTitle: parsed.batchTitle || 'Uploaded JSON Operations Batch',
            periodDays: typeof parsed.periodDays === 'number' ? parsed.periodDays : 7,
            previousPeriodNetRevenuePhp: parsed.previousPeriodNetRevenuePhp,
            receipts,
            inventory,
          },
          format: 'json',
        };
      }
    } catch (err) {
      return {
        batch: null,
        format: 'json',
        parseError: err instanceof Error ? err.message : 'Invalid JSON syntax',
      };
    }
  }

  // Basic CSV parser for receipt/inventory rows (header-driven)
  const lines = trimmed.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length >= 2 && lines[0].includes(',')) {
    const headers = lines[0].split(',').map((h) => h.trim().toLowerCase());
    const receipts: RawReceiptRecord[] = [];
    const inventory: RawInventoryRecord[] = [];

    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(',').map((c) => c.trim());
      const row: Record<string, string> = {};
      headers.forEach((h, idx) => {
        row[h] = cols[idx] ?? '';
      });

      if (row.receiptid || row.receipt_id || row.receipt) {
        const qty = Number(row.qty || row.quantity || 1);
        const unitPrice = Number(row.unitprice || row.unit_price || row.price || 0);
        const discount = Number(row.discount || 0);
        const reportedTotal =
          row.total || row.amount ? Number(row.total || row.amount) : null;
        receipts.push({
          receiptId: row.receiptid || row.receipt_id || row.receipt || `CSV-${i}`,
          date: row.date || new Date().toISOString(),
          paymentMethod: row.payment || row.paymentmethod || 'Cash',
          discountPhp: Number.isFinite(discount) ? discount : 0,
          reportedTotalPhp: reportedTotal,
          items: [
            {
              sku: row.sku || `SKU-${i}`,
              name: row.product || row.name || row.item || 'Unnamed Item',
              qty: Number.isFinite(qty) ? qty : 1,
              unitPricePhp: Number.isFinite(unitPrice) ? unitPrice : 0,
              unitCostPhp: row.cost ? Number(row.cost) : undefined,
            },
          ],
        });
      } else if (row.sku || row.product || row.name) {
        inventory.push({
          sku: row.sku || `SKU-${i}`,
          name: row.name || row.product || `Item ${i}`,
          category: row.category || 'General',
          beginningStock: Number(row.beginningstock || row.beginning || 0),
          restocks: Number(row.restocks || 0),
          actualStock: Number(row.actualstock || row.stock || 0),
          reorderThreshold: Number(row.reorderthreshold || row.threshold || 5),
          unitCostPhp: Number(row.unitcost || row.cost || 0),
          unitPricePhp: Number(row.unitprice || row.price || 0),
        });
      }
    }

    if (receipts.length > 0 || inventory.length > 0) {
      return {
        batch: {
          batchTitle: 'Imported CSV Operations Batch',
          periodDays: 7,
          receipts,
          inventory,
        },
        format: 'csv',
      };
    }
  }

  return { batch: null, format: 'pos_log' };
}

export function analyzeOperationsBatch(
  batch: OperationalBatchInput,
  profile: BotCustomizationProfile = DEFAULT_BOT_PROFILE,
  options: { confirmFix?: boolean; referenceNow?: Date } = {}
): OperationalAnalysisResult {
  const now = options.referenceNow ?? new Date('2026-11-23T09:00:00+08:00');
  const periodDays = Math.max(1, batch.periodDays ?? 7);
  const confirmFix = Boolean(options.confirmFix);

  const errors: ProposedFixRecord[] = [];
  const quarantine: QuarantineRecord[] = [];
  const variantTracker = new Map<string, { canonicalName: string; variants: Set<string> }>();
  let redactedSecretsCount = 0;
  let promptInjectionsBlocked = 0;
  let missingDataCount = 0;
  let errorCounter = 1;
  const nextErrorId = () => `ERR-${String(errorCounter++).padStart(3, '0')}`;

  // Track seen receipt IDs & canonical line totals to detect duplicates & 10x outliers
  const seenReceiptIds = new Set<string>();
  const validReceiptTotals: number[] = [];

  // First pass: compute candidate line sums so we can detect 10x outliers accurately
  const candidateAmounts = batch.receipts.map((r) => {
    const lineSum = (r.items || []).reduce(
      (sum, item) => sum + (Number.isFinite(item.qty) ? item.qty : 0) * (Number.isFinite(item.unitPricePhp) ? item.unitPricePhp : 0),
      0
    );
    return Math.max(0, lineSum - (r.discountPhp ?? 0));
  });
  const sortedNonZero = candidateAmounts.filter((v) => v > 0).sort((a, b) => a - b);
  const medianOrder =
    sortedNonZero.length > 0
      ? sortedNonZero[Math.floor(sortedNonZero.length / 2)]
      : 0;

  let grossSalesPhp = 0;
  let discountsPhp = 0;
  let netRevenuePhp = 0;
  let totalTransactions = 0;

  const productAgg = new Map<string, ProductPerformanceRow>();
  const paymentAgg = new Map<string, { transactions: number; totalPhp: number }>();
  const soldUnitsByCanonicalSku = new Map<string, number>();

  const cleanedReceipts: RawReceiptRecord[] = [];

  for (const receipt of batch.receipts) {
    const recNote = receipt.customerNote ?? '';
    const noteSanitized = redactSensitiveText(recNote);
    redactedSecretsCount += noteSanitized.redactedCount;
    if (noteSanitized.injectionBlocked) {
      promptInjectionsBlocked += 1;
    }

    // Check duplicate receipt ID
    if (seenReceiptIds.has(receipt.receiptId)) {
      errors.push({
        errorId: nextErrorId(),
        severity: 'HIGH',
        recordRef: receipt.receiptId,
        issueType: 'Duplicate Receipt ID',
        rootCause: 'Receipt number logged twice with identical timestamp and line items.',
        beforeValue: `Duplicate entry ${receipt.receiptId} (${formatPhp(receipt.reportedTotalPhp ?? 0)})`,
        afterValue: `Remove duplicate ${receipt.receiptId}`,
        autoRepairable: true,
      });
      continue;
    }
    seenReceiptIds.add(receipt.receiptId);

    // Check future date outlier
    const receiptDate = new Date(receipt.date);
    if (Number.isNaN(receiptDate.getTime())) {
      missingDataCount += 1;
      quarantine.push({
        quarantineId: `QRN-${quarantine.length + 1}`,
        recordRef: receipt.receiptId,
        reason: '[MISSING DATA — REVIEW REQUIRED] Invalid or unreadable timestamp',
        reportedAmountPhp: receipt.reportedTotalPhp ?? null,
        date: receipt.date || '[MISSING]',
      });
      continue;
    }
    if (receiptDate.getTime() > now.getTime() + 86_400_000) {
      quarantine.push({
        quarantineId: `QRN-${quarantine.length + 1}`,
        recordRef: receipt.receiptId,
        reason: 'Future-dated transaction excluded from daily revenue averages',
        reportedAmountPhp: receipt.reportedTotalPhp ?? null,
        date: receipt.date,
      });
      continue;
    }

    let computedLineSum = 0;
    const cleanedItems = [];

    for (const item of receipt.items || []) {
      const itemNameSanitized = redactSensitiveText(item.name || '');
      redactedSecretsCount += itemNameSanitized.redactedCount;
      if (itemNameSanitized.injectionBlocked) {
        promptInjectionsBlocked += 1;
      }

      const { canonicalSku, canonicalName } = canonicalizeProductName(
        itemNameSanitized.sanitized,
        item.sku
      );

      if (
        item.name &&
        item.name.trim() !== canonicalName &&
        item.sku !== canonicalSku
      ) {
        if (!variantTracker.has(canonicalSku)) {
          variantTracker.set(canonicalSku, {
            canonicalName,
            variants: new Set([canonicalName]),
          });
        }
        variantTracker.get(canonicalSku)!.variants.add(item.name.trim());
        errors.push({
          errorId: nextErrorId(),
          severity: 'MEDIUM',
          recordRef: `${receipt.receiptId} / ${item.sku}`,
          issueType: 'Naming Variant Split',
          rootCause: `Product name "${item.name}" fragments master inventory SKU ${canonicalSku}.`,
          beforeValue: `${item.sku} ("${item.name}")`,
          afterValue: `${canonicalSku} ("${canonicalName}")`,
          autoRepairable: true,
        });
      }

      if (item.unitPricePhp === 0 && !item.promoTag) {
        errors.push({
          errorId: nextErrorId(),
          severity: 'HIGH',
          recordRef: `${receipt.receiptId} / ${canonicalSku}`,
          issueType: 'Zero Unit Price Without Promo',
          rootCause: 'Item billed at ₱0.00 with no promoTag authorized.',
          beforeValue: '₱0.00',
          afterValue: '[MISSING DATA — REVIEW REQUIRED]',
          autoRepairable: false,
        });
      }

      if (
        typeof item.unitCostPhp === 'number' &&
        item.unitPricePhp > 0 &&
        item.unitPricePhp < item.unitCostPhp
      ) {
        errors.push({
          errorId: nextErrorId(),
          severity: 'HIGH',
          recordRef: `${receipt.receiptId} / ${canonicalSku}`,
          issueType: 'Selling Below Unit Cost',
          rootCause: `Unit price (${formatPhp(item.unitPricePhp)}) is below COGS (${formatPhp(item.unitCostPhp)}).`,
          beforeValue: formatPhp(item.unitPricePhp),
          afterValue: `>= ${formatPhp(item.unitCostPhp)}`,
          autoRepairable: false,
        });
      }

      computedLineSum += item.qty * item.unitPricePhp;
      cleanedItems.push({
        ...item,
        sku: canonicalSku,
        name: canonicalName,
      });
    }

    const discount = Math.max(0, receipt.discountPhp ?? 0);
    const expectedNet = Math.max(0, computedLineSum - discount);

    // Negative amount or 10x abnormal order size -> Quarantine!
    if (
      (receipt.reportedTotalPhp !== null &&
        receipt.reportedTotalPhp !== undefined &&
        receipt.reportedTotalPhp < 0) ||
      (medianOrder > 0 && expectedNet >= medianOrder * 10)
    ) {
      quarantine.push({
        quarantineId: `QRN-${quarantine.length + 1}`,
        recordRef: receipt.receiptId,
        reason:
          expectedNet >= medianOrder * 10
            ? `10x abnormal order size (${formatPhp(expectedNet)} vs median ${formatPhp(medianOrder)})`
            : 'Negative transaction amount',
        reportedAmountPhp: receipt.reportedTotalPhp ?? expectedNet,
        date: receipt.date,
      });
      continue;
    }

    if (receipt.reportedTotalPhp === null || receipt.reportedTotalPhp === undefined) {
      missingDataCount += 1;
      errors.push({
        errorId: nextErrorId(),
        severity: 'MEDIUM',
        recordRef: receipt.receiptId,
        issueType: 'Missing Reported Total',
        rootCause: 'POS export omitted reportedTotalPhp field.',
        beforeValue: '[MISSING DATA — REVIEW REQUIRED]',
        afterValue: formatPhp(expectedNet),
        autoRepairable: true,
      });
    } else if (Math.abs(receipt.reportedTotalPhp - expectedNet) > 0.01) {
      errors.push({
        errorId: nextErrorId(),
        severity: 'HIGH',
        recordRef: receipt.receiptId,
        issueType: 'Receipt Math Mismatch',
        rootCause: `Reported total does not match sum(line_items) - discount (${formatPhp(computedLineSum)} - ${formatPhp(discount)}).`,
        beforeValue: formatPhp(receipt.reportedTotalPhp),
        afterValue: formatPhp(expectedNet),
        autoRepairable: true,
      });
    }

    // Include verified receipt in sales totals
    grossSalesPhp += computedLineSum;
    discountsPhp += discount;
    netRevenuePhp += expectedNet;
    totalTransactions += 1;
    validReceiptTotals.push(expectedNet);

    const payMethod = receipt.paymentMethod?.trim() || 'Unspecified';
    const currentPay = paymentAgg.get(payMethod) ?? { transactions: 0, totalPhp: 0 };
    currentPay.transactions += 1;
    currentPay.totalPhp += expectedNet;
    paymentAgg.set(payMethod, currentPay);

    for (const item of cleanedItems) {
      soldUnitsByCanonicalSku.set(
        item.sku,
        (soldUnitsByCanonicalSku.get(item.sku) ?? 0) + item.qty
      );

      const lineRev = item.qty * item.unitPricePhp;
      const existingProd = productAgg.get(item.sku) ?? {
        canonicalSku: item.sku,
        canonicalName: item.name,
        unitsSold: 0,
        revenuePhp: 0,
        unitCostPhp: item.unitCostPhp ?? null,
        grossProfitPhp: item.unitCostPhp !== undefined ? 0 : null,
        marginPct: null,
        lowMarginFlag: false,
      };
      existingProd.unitsSold += item.qty;
      existingProd.revenuePhp += lineRev;
      if (item.unitCostPhp !== undefined && existingProd.grossProfitPhp !== null) {
        existingProd.grossProfitPhp += lineRev - item.qty * item.unitCostPhp;
      }
      productAgg.set(item.sku, existingProd);
    }

    cleanedReceipts.push({
      ...receipt,
      customerNote: noteSanitized.sanitized,
      reportedTotalPhp: expectedNet,
      items: cleanedItems,
    });
  }

  // Finalize Product Performance & Margin Guard (< 15%)
  const topProducts = Array.from(productAgg.values())
    .map((p) => {
      const marginPct =
        p.grossProfitPhp !== null && p.revenuePhp > 0
          ? Number(((p.grossProfitPhp / p.revenuePhp) * 100).toFixed(2))
          : null;
      return {
        ...p,
        marginPct,
        lowMarginFlag: marginPct !== null && marginPct < 15,
      };
    })
    .sort((a, b) => b.revenuePhp - a.revenuePhp)
    .slice(0, 5);

  const paymentBreakdown: PaymentSplitRow[] = Array.from(paymentAgg.entries())
    .map(([method, data]) => ({
      method,
      transactions: data.transactions,
      totalPhp: data.totalPhp,
      sharePct:
        netRevenuePhp > 0
          ? Number(((data.totalPhp / netRevenuePhp) * 100).toFixed(1))
          : 0,
    }))
    .sort((a, b) => b.totalPhp - a.totalPhp);

  // Merge and reconcile Inventory items by canonical SKU
  const mergedInventoryMap = new Map<string, RawInventoryRecord>();
  for (const inv of batch.inventory) {
    const { canonicalSku, canonicalName } = canonicalizeProductName(
      inv.name,
      inv.sku
    );

    if (inv.name.trim() !== canonicalName || inv.sku !== canonicalSku) {
      if (!variantTracker.has(canonicalSku)) {
        variantTracker.set(canonicalSku, {
          canonicalName,
          variants: new Set([canonicalName]),
        });
      }
      variantTracker.get(canonicalSku)!.variants.add(inv.name.trim());
    }

    if (inv.actualStock < 0) {
      errors.push({
        errorId: nextErrorId(),
        severity: 'CRITICAL',
        recordRef: `${inv.sku} (${inv.name})`,
        issueType: 'Negative Stock Count',
        rootCause: 'Physical stock cannot be negative; likely missed restock log or scan glitch.',
        beforeValue: `${inv.actualStock} units`,
        afterValue: `${Math.max(0, inv.beginningStock + inv.restocks - (soldUnitsByCanonicalSku.get(canonicalSku) ?? 0))} units (Expected)`,
        autoRepairable: true,
      });
    }

    const existing = mergedInventoryMap.get(canonicalSku);
    if (!existing) {
      mergedInventoryMap.set(canonicalSku, {
        ...inv,
        sku: canonicalSku,
        name: canonicalName,
      });
    } else {
      existing.beginningStock += inv.beginningStock;
      existing.restocks += inv.restocks;
      existing.actualStock += Math.max(0, inv.actualStock);
      existing.reorderThreshold = Math.max(
        existing.reorderThreshold ?? 5,
        inv.reorderThreshold ?? 5
      );
    }
  }

  const inventoryHealth: InventoryHealthRow[] = [];
  const slowMovers: string[] = [];
  const repairedInventory: RawInventoryRecord[] = [];

  for (const inv of mergedInventoryMap.values()) {
    const unitsSold = soldUnitsByCanonicalSku.get(inv.sku) ?? inv.unitsSoldReported ?? 0;
    const expectedEndingStock = inv.beginningStock + inv.restocks - unitsSold;
    const actualSafe = Math.max(0, inv.actualStock);
    const variance = inv.actualStock - expectedEndingStock;
    const threshold = inv.reorderThreshold ?? 5;
    const dailyVelocity = Number((unitsSold / periodDays).toFixed(2));
    const daysUntilStockout =
      dailyVelocity > 0 ? Number((actualSafe / dailyVelocity).toFixed(1)) : null;

    let status: StockStatus = 'HEALTHY';
    if (actualSafe === 0) {
      status = 'CRITICAL';
    } else if (actualSafe <= threshold || actualSafe < 5) {
      status = 'LOW_STOCK';
    } else if (unitsSold === 0 && actualSafe >= threshold * 3) {
      status = 'OVERSTOCK';
      slowMovers.push(inv.name);
    }

    if (unitsSold === 0 && status !== 'OVERSTOCK') {
      slowMovers.push(inv.name);
    }

    const target14DayCover = Math.ceil(dailyVelocity * 14);
    const recommendedReorderQty =
      status === 'CRITICAL' || status === 'LOW_STOCK'
        ? Math.max(threshold * 2 - actualSafe, target14DayCover - actualSafe, 5)
        : 0;

    const unitCost = inv.unitCostPhp ?? 0;
    const unitPrice = inv.unitPricePhp ?? 0;
    const marginPct =
      unitPrice > 0 && unitCost > 0
        ? Number((((unitPrice - unitCost) / unitPrice) * 100).toFixed(2))
        : null;
    const lowMarginFlag = marginPct !== null && marginPct < 15;

    if (variance !== 0 && inv.actualStock >= 0) {
      errors.push({
        errorId: nextErrorId(),
        severity: 'MEDIUM',
        recordRef: inv.sku,
        issueType: 'Stock Reconciliation Variance',
        rootCause: `Expected ending stock (${expectedEndingStock}) differs from reported actual (${inv.actualStock}).`,
        beforeValue: `${inv.actualStock} units`,
        afterValue: `${Math.max(0, expectedEndingStock)} units`,
        autoRepairable: true,
      });
    }

    inventoryHealth.push({
      canonicalSku: inv.sku,
      canonicalName: inv.name,
      category: inv.category,
      beginningStock: inv.beginningStock,
      restocks: inv.restocks,
      unitsSold,
      expectedEndingStock,
      actualStock: actualSafe,
      variance,
      reorderThreshold: threshold,
      dailyVelocity,
      daysUntilStockout,
      recommendedReorderQty,
      status,
      unitCostPhp: unitCost,
      unitPricePhp: unitPrice,
      marginPct,
      lowMarginFlag,
    });

    repairedInventory.push({
      ...inv,
      actualStock: confirmFix ? Math.max(0, expectedEndingStock) : actualSafe,
    });
  }

  const normalizations: EntityNormalizationSuggestion[] = Array.from(
    variantTracker.entries()
  )
    .filter(([, data]) => data.variants.size > 1)
    .map(([canonicalSku, data]) => ({
      canonicalSku,
      canonicalName: data.canonicalName,
      mergedVariants: Array.from(data.variants),
    }));

  const averageOrderValuePhp =
    totalTransactions > 0 ? netRevenuePhp / totalTransactions : 0;

  const wowTrendPct =
    typeof batch.previousPeriodNetRevenuePhp === 'number' &&
    batch.previousPeriodNetRevenuePhp > 0
      ? Number(
          (
            ((netRevenuePhp - batch.previousPeriodNetRevenuePhp) /
              batch.previousPeriodNetRevenuePhp) *
            100
          ).toFixed(1)
        )
      : null;

  // Build top 3 urgent alerts
  const actionRequiredToday: string[] = [];
  const criticalItems = inventoryHealth.filter((i) => i.status === 'CRITICAL');
  if (criticalItems.length > 0) {
    actionRequiredToday.push(
      `CRITICAL STOCKOUT: ${criticalItems.map((i) => `${i.canonicalName} (0 left — reorder ${i.recommendedReorderQty} units)`).join(', ')}`
    );
  }
  const lowItems = inventoryHealth.filter((i) => i.status === 'LOW_STOCK');
  if (lowItems.length > 0) {
    actionRequiredToday.push(
      `LOW STOCK WATCH: ${lowItems.map((i) => `${i.canonicalName} (${i.actualStock} left, ~${i.daysUntilStockout ?? '?'}d cover)`).join(', ')}`
    );
  }
  if (quarantine.length > 0 || errors.length > 0) {
    actionRequiredToday.push(
      `DATA INTEGRITY: ${errors.length} error(s) flagged & ${quarantine.length} outlier(s) quarantined — ${confirmFix ? 'repaired & locked' : 'awaiting CONFIRM FIX'}.`
    );
  }
  const lowMarginItems = [
    ...topProducts.filter((p) => p.lowMarginFlag),
    ...inventoryHealth.filter((i) => i.lowMarginFlag),
  ];
  if (actionRequiredToday.length < 3 && lowMarginItems.length > 0) {
    const firstLow = lowMarginItems[0];
    actionRequiredToday.push(
      `MARGIN GUARD (<15%): ${firstLow.canonicalName} at ${firstLow.marginPct}% gross margin.`
    );
  }

  // Determine 3D scene cue & avatar animation state
  const hasCritical = criticalItems.length > 0 || quarantine.length > 0;
  const hasWarnings = errors.length > 0 || lowItems.length > 0;

  let bot3dState: Bot3DState;
  let sceneCue: string;

  if (confirmFix) {
    bot3dState = {
      bot_name: profile.botName,
      animation: 'repairing_code',
      expression: 'happy',
      office_lighting: 'celebration_gold',
      hologram_screens: ['sales_chart', 'inventory_grid', 'error_diff_terminal'],
      write_lock_status: 'CONFIRMED_AND_EXPORTED',
    };
    sceneCue = `[3D Scene: ${profile.botName} locks in the verified repair patch with dual holographic arms, illuminates the ${profile.companyName} desk in celebration gold, and prints a timestamped Audit Change Log.]`;
  } else if (hasCritical) {
    bot3dState = {
      bot_name: profile.botName,
      animation: 'warning_alert',
      expression: 'alert',
      office_lighting: 'caution_amber',
      hologram_screens: ['sales_chart', 'inventory_grid', 'error_diff_terminal'],
      write_lock_status: 'AWAITING_CONFIRM_FIX',
    };
    sceneCue = `[3D Scene: Amber beacon spins in the ${profile.companyName} 3D stockroom. ${profile.botName} flips down diagnostic cyber-goggles and isolates ${quarantine.length} anomalous cube(s) while flagging ${criticalItems.length} stockout(s).]`;
  } else if (hasWarnings) {
    bot3dState = {
      bot_name: profile.botName,
      animation: 'scanning_hologram',
      expression: 'focused',
      office_lighting: 'studio_blue',
      hologram_screens: ['sales_chart', 'inventory_grid', 'error_diff_terminal'],
      write_lock_status: 'AWAITING_CONFIRM_FIX',
    };
    sceneCue = `[3D Scene: ${profile.botName} glides up to the holographic console under crisp studio lighting, lining up ${errors.length} proposed BEFORE -> AFTER repair cards for review.]`;
  } else {
    bot3dState = {
      bot_name: profile.botName,
      animation: 'celebrating',
      expression: 'happy',
      office_lighting: 'celebration_gold',
      hologram_screens: ['sales_chart', 'inventory_grid', 'error_diff_terminal'],
      write_lock_status: 'AWAITING_CONFIRM_FIX',
    };
    sceneCue = `[3D Scene: Office lights flash celebratory gold! ${profile.botName} gives a cheerful double thumbs-up as clean emerald PHP revenue bars rise above the ${profile.companyName} console.]`;
  }

  const auditChangeLog: AuditChangeLogEntry[] = confirmFix
    ? [
        {
          timestampManila: getManilaTimestamp(now),
          action: 'CONFIRM FIX EXECUTED',
          errorIds: errors.filter((e) => e.autoRepairable).map((e) => e.errorId),
          note: `Save a backup snapshot before importing. Redacted ${redactedSecretsCount} secret(s), blocked ${promptInjectionsBlocked} injection(s), quarantined ${quarantine.length} outlier(s).`,
        },
      ]
    : [];

  return {
    sceneCue,
    actionRequiredToday: actionRequiredToday.slice(0, 3),
    salesSummary: {
      grossSalesPhp,
      discountsPhp,
      netRevenuePhp,
      totalTransactions,
      averageOrderValuePhp,
      wowTrendPct,
      missingDataCount,
      topProducts,
      slowMovers: Array.from(new Set(slowMovers)),
      paymentBreakdown,
    },
    inventoryHealth,
    errors,
    quarantine,
    normalizations,
    redactedSecretsCount,
    promptInjectionsBlocked,
    writeLockStatus: confirmFix ? 'CONFIRMED_AND_EXPORTED' : 'AWAITING_CONFIRM_FIX',
    repairedPayload: confirmFix
      ? {
          batchTitle: `${batch.batchTitle ?? 'Pempam Batch'} (REPAIRED)`,
          periodDays,
          receipts: cleanedReceipts,
          inventory: repairedInventory,
        }
      : null,
    auditChangeLog,
    bot3dState,
  };
}
