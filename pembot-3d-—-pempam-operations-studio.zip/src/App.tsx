import { useCallback, useEffect, useRef, useState } from 'react';
import { User } from 'firebase/auth';
import {
  Bot3DState,
  BotAnimationState,
  BotCustomizationProfile,
  CalendarEventItem,
  OfficeTheme,
  OperationalAnalysisResult,
  OperationalBatchInput,
  PendingCalendarAction,
} from './types/operations';
import { PEMPAM_SAMPLE_BATCH } from './data/pempamSampleData';
import {
  analyzeOperationsBatch,
  DEFAULT_BOT_PROFILE,
  parseCustomizationCommand,
  parseRawInputToBatch,
} from './utils/operationsEngine';
import {
  getCalendarAccessToken,
  googleSignIn,
  initAuth,
  logout,
} from './lib/firebase';
import {
  confirmAuditRunInFirestore,
  loadUserProfile,
  saveAuditRun,
  saveUserProfile,
  StoredAuditRun,
  subscribeAudits,
  subscribeInventory,
  syncInventoryRows,
} from './lib/firestoreSync';
import {
  createCalendarEvent,
  fetchUpcomingCalendarEvents,
} from './lib/calendarClient';
import { LiveVoiceSession } from './lib/liveVoiceClient';
import { CameraPreset, OfficeViewport } from './three/OfficeViewport';
import { StudioTab, TopBar } from './components/TopBar';
import { BottomControlDock } from './components/BottomControlDock';
import { OperationsDrawer } from './components/OperationsDrawer';
import { OperationsTab } from './components/tabs/OperationsTab';
import { InventoryTab } from './components/tabs/InventoryTab';
import { CalendarTab } from './components/tabs/CalendarTab';
import { CustomizeTab } from './components/tabs/CustomizeTab';
import { SystemsTab } from './components/tabs/SystemsTab';
import { ConfirmScheduleModal } from './components/ConfirmScheduleModal';
import {
  buildLiveAppsContextSummary,
  buildLivePempamBatch,
  LivePempamSnapshot,
  readLivePempamStorage,
  writeRepairsToLiveStorage,
} from './utils/pempamAppsBridge';

export default function App() {
  const [profile, setProfile] = useState<BotCustomizationProfile>(
    DEFAULT_BOT_PROFILE
  );
  const [activeBatch, setActiveBatch] = useState<OperationalBatchInput>(
    PEMPAM_SAMPLE_BATCH
  );
  const [analysis, setAnalysis] = useState<OperationalAnalysisResult>(() =>
    analyzeOperationsBatch(PEMPAM_SAMPLE_BATCH, DEFAULT_BOT_PROFILE, {
      confirmFix: false,
    })
  );
  const [bot3dState, setBot3dState] = useState<Bot3DState>(
    () =>
      analyzeOperationsBatch(PEMPAM_SAMPLE_BATCH, DEFAULT_BOT_PROFILE, {
        confirmFix: false,
      }).bot3dState
  );

  // UI Layout state
  const [drawerOpen, setDrawerOpen] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<StudioTab>('operations');
  const [dockCollapsed, setDockCollapsed] = useState<boolean>(false);
  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('desk');

  // Operations & Gemini state
  const [rawInput, setRawInput] = useState<string>('');
  const [thinkingMode, setThinkingMode] = useState<'fast' | 'deep'>('deep');
  const [opsBusy, setOpsBusy] = useState<boolean>(false);
  const [opsError, setOpsError] = useState<string | null>(null);
  const [activeAuditDocId, setActiveAuditDocId] = useState<string | null>(null);
  const [activeBatchSource, setActiveBatchSource] = useState<
    'sample' | 'live_apps' | 'custom_paste'
  >('sample');
  const [liveSnapshot, setLiveSnapshot] = useState<LivePempamSnapshot>(() =>
    readLivePempamStorage()
  );
  const [iframeNonce, setIframeNonce] = useState<number>(0);

  // Firebase Auth & Firestore state
  const [user, setUser] = useState<User | null>(null);
  const [calendarToken, setCalendarToken] = useState<string | null>(null);
  const [authBusy, setAuthBusy] = useState<boolean>(false);
  const [savingProfile, setSavingProfile] = useState<boolean>(false);
  const [storedAudits, setStoredAudits] = useState<StoredAuditRun[]>([]);
  const [firestoreError, setFirestoreError] = useState<Error | null>(null);

  // Google Calendar state
  const [calendarEvents, setCalendarEvents] = useState<CalendarEventItem[]>([]);
  const [calendarLoading, setCalendarLoading] = useState<boolean>(false);
  const [calendarError, setCalendarError] = useState<string | null>(null);
  const [pendingCalendar, setPendingCalendar] =
    useState<PendingCalendarAction | null>(null);
  const [calendarCreateBusy, setCalendarCreateBusy] = useState<boolean>(false);

  // Gemini Live Voice state
  const [voiceStatus, setVoiceStatus] = useState<
    'idle' | 'connecting' | 'connected' | 'error'
  >('idle');
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [voiceTranscripts, setVoiceTranscripts] = useState<
    Array<{ role: 'user' | 'bot'; text: string }>
  >([]);
  const liveSessionRef = useRef<LiveVoiceSession | null>(null);

  if (firestoreError) {
    throw firestoreError;
  }

  // Refresh live Pempam storage telemetry on focus/storage events
  const refreshLiveSnapshot = useCallback(() => {
    setLiveSnapshot(readLivePempamStorage());
  }, []);

  useEffect(() => {
    const onStorageOrFocus = () => refreshLiveSnapshot();
    window.addEventListener('storage', onStorageOrFocus);
    window.addEventListener('focus', onStorageOrFocus);
    return () => {
      window.removeEventListener('storage', onStorageOrFocus);
      window.removeEventListener('focus', onStorageOrFocus);
    };
  }, [refreshLiveSnapshot]);

  // Keyboard shortcut 'H' to toggle bottom control dock
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (e.key.toLowerCase() === 'h') {
        setDockCollapsed((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  // Auth listener + Firestore subscriptions
  useEffect(() => {
    let unsubAudits: (() => void) | null = null;
    let unsubInv: (() => void) | null = null;

    const unsubAuth = initAuth(
      async (authedUser, token) => {
        setUser(authedUser);
        setCalendarToken(token ?? getCalendarAccessToken());

        try {
          const loaded = await loadUserProfile(authedUser.uid);
          if (loaded) {
            setProfile(loaded);
          } else {
            await saveUserProfile(
              authedUser.uid,
              authedUser.displayName || 'Pempam Operator',
              authedUser.email || 'operator@pempam.local',
              DEFAULT_BOT_PROFILE
            );
          }
        } catch (err) {
          setFirestoreError(
            err instanceof Error ? err : new Error(String(err))
          );
        }

        unsubAudits?.();
        unsubAudits = subscribeAudits(
          authedUser.uid,
          (audits) => setStoredAudits(audits),
          (err) => setFirestoreError(err)
        );

        unsubInv?.();
        unsubInv = subscribeInventory(
          authedUser.uid,
          (rows) => {
            if (rows.length > 0) {
              setAnalysis((prev) => ({ ...prev, inventoryHealth: rows }));
            }
          },
          (err) => setFirestoreError(err)
        );
      },
      () => {
        setUser(null);
        setCalendarToken(null);
        setStoredAudits([]);
        setCalendarEvents([]);
        unsubAudits?.();
        unsubInv?.();
      }
    );

    return () => {
      unsubAuth();
      unsubAudits?.();
      unsubInv?.();
      liveSessionRef.current?.stop();
    };
  }, []);

  const refreshCalendar = useCallback(async (tokenOverride?: string | null) => {
    const token = tokenOverride ?? getCalendarAccessToken();
    if (!token) return;
    setCalendarLoading(true);
    setCalendarError(null);
    try {
      const items = await fetchUpcomingCalendarEvents(token);
      setCalendarEvents(items);
    } catch (err) {
      setCalendarError(
        err instanceof Error ? err.message : 'Unable to load Google Calendar.'
      );
    } finally {
      setCalendarLoading(false);
    }
  }, []);

  const handleSignIn = async () => {
    setAuthBusy(true);
    setCalendarError(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setCalendarToken(res.accessToken);
        if (res.accessToken) {
          await refreshCalendar(res.accessToken);
        }
      }
    } catch (err) {
      setOpsError(
        err instanceof Error ? err.message : 'Google Sign-In failed.'
      );
    } finally {
      setAuthBusy(false);
    }
  };

  const handleSignOut = async () => {
    setAuthBusy(true);
    try {
      await logout();
    } finally {
      setAuthBusy(false);
    }
  };

  const handleSelectTab = (tab: StudioTab) => {
    if (drawerOpen && activeTab === tab) {
      setDrawerOpen(false);
    } else {
      setActiveTab(tab);
      setDrawerOpen(true);
    }
  };

  const handleSaveCloudProfile = async () => {
    if (!user) return;
    setSavingProfile(true);
    try {
      await saveUserProfile(
        user.uid,
        user.displayName || 'Pempam Operator',
        user.email || 'operator@pempam.local',
        profile
      );
    } catch (err) {
      setFirestoreError(err instanceof Error ? err : new Error(String(err)));
    } finally {
      setSavingProfile(false);
    }
  };

  const handleLoadSample = () => {
    setOpsError(null);
    setActiveBatchSource('sample');
    setActiveBatch(PEMPAM_SAMPLE_BATCH);
    const result = analyzeOperationsBatch(PEMPAM_SAMPLE_BATCH, profile, {
      confirmFix: false,
    });
    setAnalysis(result);
    setBot3dState(result.bot3dState);
    setActiveAuditDocId(null);
    setRawInput(JSON.stringify(PEMPAM_SAMPLE_BATCH, null, 2));
  };

  const handleSyncLiveApps = async () => {
    setOpsError(null);
    const freshSnapshot = readLivePempamStorage();
    setLiveSnapshot(freshSnapshot);

    if (!freshSnapshot.hasGloNextData && !freshSnapshot.hasRepairData) {
      setOpsError(
        'No saved GloNext POS or Repair Receipt records found yet. Opening Pempam Apps so you can initialize or log a record first.'
      );
      setActiveTab('systems');
      setDrawerOpen(true);
      return;
    }

    const liveBatch = buildLivePempamBatch(freshSnapshot);
    setActiveBatchSource('live_apps');
    setActiveBatch(liveBatch);
    const result = analyzeOperationsBatch(liveBatch, profile, {
      confirmFix: false,
    });
    result.sceneCue = `[3D Scene: ${profile.botName} syncs directly with live GloNext POS (${freshSnapshot.metrics.posCompletedSalesCount} sales, ${freshSnapshot.metrics.posProductsCount} SKUs) and Repair Desk (${freshSnapshot.metrics.repairPendingCount} pending unit(s)) on the holographic console.]`;
    setAnalysis(result);
    setBot3dState(result.bot3dState);
    setActiveAuditDocId(null);
    setActiveTab('operations');
    setDrawerOpen(true);

    if (user) {
      try {
        const auditId = await saveAuditRun(
          user.uid,
          `live-sync-${Date.now()}`,
          liveBatch.batchTitle || 'Live Pempam POS & Repair Audit',
          'pos_log',
          JSON.stringify(liveBatch),
          result
        );
        setActiveAuditDocId(auditId);
        await syncInventoryRows(user.uid, result.inventoryHealth);
      } catch (err) {
        setFirestoreError(err instanceof Error ? err : new Error(String(err)));
      }
    }
  };

  const handleConfirmFix = async () => {
    const unlocked = analyzeOperationsBatch(activeBatch, profile, {
      confirmFix: true,
    });

    if (activeBatchSource === 'live_apps' && unlocked.repairedPayload) {
      const writeOutcome = writeRepairsToLiveStorage(
        window.localStorage,
        unlocked.repairedPayload
      );
      if (writeOutcome.updatedGloNext) {
        setIframeNonce((n) => n + 1);
        setLiveSnapshot(readLivePempamStorage());
      }
    }

    setAnalysis(unlocked);
    setBot3dState(unlocked.bot3dState);

    if (user) {
      try {
        if (activeAuditDocId) {
          await confirmAuditRunInFirestore(user.uid, activeAuditDocId, unlocked);
        } else {
          const id = await saveAuditRun(
            user.uid,
            `audit-${Date.now()}`,
            activeBatch.batchTitle || 'Pempam Batch Audit',
            activeBatchSource === 'live_apps' ? 'pos_log' : 'json',
            JSON.stringify(activeBatch),
            unlocked
          );
          setActiveAuditDocId(id);
        }
        await syncInventoryRows(user.uid, unlocked.inventoryHealth);
      } catch (err) {
        setFirestoreError(err instanceof Error ? err : new Error(String(err)));
      }
    }
  };

  const handleRunCommandOrAudit = async (overrideText?: string) => {
    const input = (overrideText ?? rawInput).trim();
    if (!input) {
      setOpsError('Enter a question, customization command, or POS/stock batch first.');
      return;
    }
    setOpsError(null);

    // Check Two-Step Write Lock confirmation command
    if (/^confirm\s+fix$/i.test(input)) {
      await handleConfirmFix();
      return;
    }

    // Check interactive /customize command
    const customCmd = parseCustomizationCommand(input, profile);
    if (customCmd.matched) {
      setProfile(customCmd.updated);
      const refreshed = analyzeOperationsBatch(activeBatch, customCmd.updated, {
        confirmFix: analysis.writeLockStatus === 'CONFIRMED_AND_EXPORTED',
      });
      refreshed.sceneCue = `[3D Scene: ${customCmd.updated.botName} shifts seamlessly into its updated ${customCmd.updated.outfitStyle.replace('_', ' ')} look inside the ${customCmd.updated.officeTheme.replace('_', ' ')} office — ${customCmd.summary}]`;
      setAnalysis(refreshed);
      setBot3dState({
        ...refreshed.bot3dState,
        animation: 'celebrating',
        expression: 'happy',
        office_lighting: 'celebration_gold',
      });
      if (user) {
        try {
          await saveUserProfile(
            user.uid,
            user.displayName || 'Pempam Operator',
            user.email || 'operator@pempam.local',
            customCmd.updated
          );
        } catch (err) {
          setFirestoreError(err instanceof Error ? err : new Error(String(err)));
        }
      }
      return;
    }

    // Parse if JSON / CSV batch was pasted
    const parsedBatch = parseRawInputToBatch(input);
    if (parsedBatch.parseError) {
      setOpsError(`Syntax error in pasted batch: ${parsedBatch.parseError}`);
      return;
    }

    let targetBatch = activeBatch;
    let computed = analysis;
    if (parsedBatch.batch) {
      targetBatch = parsedBatch.batch;
      setActiveBatchSource('custom_paste');
      setActiveBatch(targetBatch);
      computed = analyzeOperationsBatch(targetBatch, profile, {
        confirmFix: false,
      });
      setAnalysis(computed);
      setBot3dState(computed.bot3dState);
    }

    const freshLiveSnapshot = readLivePempamStorage();
    setLiveSnapshot(freshLiveSnapshot);

    // Call server-side Gemini endpoint (/api/analyze)
    setOpsBusy(true);
    try {
      const promptMsg = parsedBatch.batch
        ? `Analyze this ${parsedBatch.format.toUpperCase()} batch for ${profile.companyName} and summarize urgent alerts, revenue health, stockout risk, and proposed repairs.`
        : input;

      const resp = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: promptMsg,
          mode: thinkingMode,
          profile,
          analysisSummary: {
            salesSummary: computed.salesSummary,
            actionRequiredToday: computed.actionRequiredToday,
            errors: computed.errors,
            quarantine: computed.quarantine,
            normalizations: computed.normalizations,
            writeLockStatus: computed.writeLockStatus,
            connectedPempamApps: buildLiveAppsContextSummary(freshLiveSnapshot),
          },
        }),
      });

      const data = await resp.json();
      if (!resp.ok) {
        throw new Error(data.error || 'Gemini analysis failed.');
      }

      const nextResult: OperationalAnalysisResult = {
        ...computed,
        sceneCue: data.sceneCue || computed.sceneCue,
        aiNarrative: data.narrative,
        modelUsed: data.modelUsed,
        thinkingMode: data.thinkingMode,
        bot3dState: {
          ...computed.bot3dState,
          animation: data.bot3dState?.animation || computed.bot3dState.animation,
          expression:
            data.bot3dState?.expression || computed.bot3dState.expression,
          office_lighting:
            data.bot3dState?.office_lighting ||
            computed.bot3dState.office_lighting,
        },
      };

      setAnalysis(nextResult);
      setBot3dState(nextResult.bot3dState);

      if (user) {
        const auditId = await saveAuditRun(
          user.uid,
          `audit-${Date.now()}`,
          targetBatch.batchTitle || 'Pempam Operations Audit',
          parsedBatch.format,
          input,
          nextResult
        );
        setActiveAuditDocId(auditId);
        await syncInventoryRows(user.uid, nextResult.inventoryHealth);
      }
    } catch (err) {
      setOpsError(
        err instanceof Error ? err.message : 'Unable to reach Gemini backend.'
      );
    } finally {
      setOpsBusy(false);
    }
  };

  const handleToggleVoice = async () => {
    if (voiceStatus === 'connected' || voiceStatus === 'connecting') {
      liveSessionRef.current?.stop();
      liveSessionRef.current = null;
      setVoiceStatus('idle');
      setIsSpeaking(false);
      return;
    }

    const session = new LiveVoiceSession({
      onStatusChange: (status, detail) => {
        if (status === 'connecting') setVoiceStatus('connecting');
        else if (status === 'connected') setVoiceStatus('connected');
        else if (status === 'error') {
          setVoiceStatus('error');
          if (detail) setOpsError(detail);
        } else {
          setVoiceStatus('idle');
        }
      },
      onSpeakingChange: (speaking) => setIsSpeaking(speaking),
      onTranscript: (role, text) => {
        setVoiceTranscripts((prev) => [...prev.slice(-11), { role, text }]);
      },
    });
    liveSessionRef.current = session;
    try {
      await session.start();
      setDrawerOpen(true);
      setActiveTab('operations');
    } catch (err) {
      setVoiceStatus('error');
      setOpsError(
        err instanceof Error
          ? err.message
          : 'Microphone access or Live Voice connection failed.'
      );
    }
  };

  const handleConfirmCalendarCreate = async () => {
    if (!pendingCalendar) return;
    const token = calendarToken ?? getCalendarAccessToken();
    if (!token) {
      setPendingCalendar(null);
      setCalendarError('Please sign in with Google to authorize Calendar access.');
      return;
    }
    setCalendarCreateBusy(true);
    try {
      await createCalendarEvent(token, pendingCalendar);
      setPendingCalendar(null);
      await refreshCalendar(token);
      setActiveTab('calendar');
      setDrawerOpen(true);
    } catch (err) {
      setCalendarError(
        err instanceof Error ? err.message : 'Failed to create calendar event.'
      );
    } finally {
      setCalendarCreateBusy(false);
    }
  };

  return (
    <div className="relative flex h-screen w-screen flex-col overflow-hidden bg-slate-950">
      <TopBar
        companyName={profile.companyName}
        botName={profile.botName}
        activeTab={activeTab}
        drawerOpen={drawerOpen}
        onSelectTab={handleSelectTab}
        user={user}
        authBusy={authBusy}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
      />

      <main className="relative flex-1 overflow-hidden">
        {/* Full-bleed 3D Three.js Stage */}
        <OfficeViewport
          profile={profile}
          bot3dState={bot3dState}
          analysis={analysis}
          cameraPreset={cameraPreset}
          isSpeaking={isSpeaking}
          drawerOpen={drawerOpen}
        />

        {/* Subtle Top-Left 3D Scene Cue Overlay (No backdrop-filter over WebGL) */}
        <div
          className={`pointer-events-none fixed top-18 right-4 left-4 z-10 rounded-xl border border-slate-800/80 bg-slate-950/90 px-3.5 py-2.5 text-slate-100 shadow-lg sm:right-auto ${
            drawerOpen && activeTab === 'systems'
              ? 'hidden xl:block xl:max-w-[330px] 2xl:max-w-sm'
              : 'max-w-sm'
          }`}
        >
          <div className="flex items-center justify-between gap-3 text-[11px] font-semibold text-slate-400">
            <span>{profile.botName}</span>
            <span className="font-mono-tabular uppercase">
              {bot3dState.animation.replace('_', ' ')}
            </span>
          </div>
          <p className="mt-1 text-xs leading-relaxed text-slate-200">
            {analysis.sceneCue}
          </p>
        </div>

        {/* Collapsible Bottom 3D Controls Dock */}
        <BottomControlDock
          collapsed={dockCollapsed}
          onToggleCollapse={() => setDockCollapsed((c) => !c)}
          officeTheme={profile.officeTheme}
          onChangeTheme={(theme: OfficeTheme) =>
            setProfile((p) => ({ ...p, officeTheme: theme }))
          }
          animationState={bot3dState.animation}
          onChangeAnimation={(anim: BotAnimationState) =>
            setBot3dState((prev) => ({
              ...prev,
              animation: anim,
              expression:
                anim === 'celebrating' || anim === 'repairing_code'
                  ? 'happy'
                  : anim === 'warning_alert'
                    ? 'alert'
                    : anim === 'shield_locked'
                      ? 'protective'
                      : 'focused',
              office_lighting:
                anim === 'celebrating'
                  ? 'celebration_gold'
                  : anim === 'warning_alert'
                    ? 'caution_amber'
                    : anim === 'shield_locked'
                      ? 'quarantine_red'
                      : 'studio_blue',
            }))
          }
          cameraPreset={cameraPreset}
          onChangeCamera={setCameraPreset}
          voiceStatus={voiceStatus}
          onToggleVoice={handleToggleVoice}
          drawerOpen={drawerOpen}
          wideDrawer={activeTab === 'systems'}
          onToggleDrawer={() => setDrawerOpen((o) => !o)}
        />

        {/* Slide-Over Operations Studio Drawer */}
        <OperationsDrawer
          open={drawerOpen}
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          onClose={() => setDrawerOpen(false)}
        >
          {activeTab === 'operations' && (
            <OperationsTab
              profile={profile}
              analysis={analysis}
              rawInput={rawInput}
              onChangeRawInput={setRawInput}
              thinkingMode={thinkingMode}
              onChangeThinkingMode={setThinkingMode}
              busy={opsBusy}
              errorMsg={opsError}
              onLoadSample={handleLoadSample}
              onSyncLiveApps={handleSyncLiveApps}
              onOpenSystems={() => {
                refreshLiveSnapshot();
                setActiveTab('systems');
              }}
              liveStatusLabel={
                liveSnapshot.hasGloNextData || liveSnapshot.hasRepairData
                  ? `Live Apps Ready · POS: ${liveSnapshot.metrics.posProductsCount} SKUs / ${liveSnapshot.metrics.posCompletedSalesCount} sales · Repairs: ${liveSnapshot.metrics.repairPendingCount} pending`
                  : 'Connected Apps: Open Pempam Apps tab to initialize POS or Repair Desk'
              }
              onRunCommandOrAudit={handleRunCommandOrAudit}
              onConfirmFix={handleConfirmFix}
              voiceTranscripts={voiceTranscripts}
              storedAudits={storedAudits}
            />
          )}

          {activeTab === 'inventory' && (
            <InventoryTab
              rows={analysis.inventoryHealth}
              onProposeRestockEvent={(action) => setPendingCalendar(action)}
            />
          )}

          {activeTab === 'systems' && (
            <SystemsTab
              snapshot={liveSnapshot}
              iframeNonce={iframeNonce}
              onRefreshSnapshot={refreshLiveSnapshot}
              onSyncToAgent={handleSyncLiveApps}
            />
          )}

          {activeTab === 'calendar' && (
            <CalendarTab
              hasToken={Boolean(calendarToken)}
              events={calendarEvents}
              loading={calendarLoading}
              errorMsg={calendarError}
              onSignIn={handleSignIn}
              onRefreshEvents={() => refreshCalendar()}
              onProposeEvent={(action) => setPendingCalendar(action)}
            />
          )}

          {activeTab === 'customize' && (
            <CustomizeTab
              profile={profile}
              onChangeProfile={setProfile}
              isSignedIn={Boolean(user)}
              saving={savingProfile}
              onSaveCloud={handleSaveCloudProfile}
            />
          )}
        </OperationsDrawer>
      </main>

      <ConfirmScheduleModal
        pending={pendingCalendar}
        busy={calendarCreateBusy}
        onConfirm={handleConfirmCalendarCreate}
        onCancel={() => setPendingCalendar(null)}
      />
    </div>
  );
}
