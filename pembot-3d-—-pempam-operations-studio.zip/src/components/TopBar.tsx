import React from 'react';
import { User } from 'firebase/auth';

export type StudioTab =
  | 'operations'
  | 'inventory'
  | 'systems'
  | 'calendar'
  | 'customize';

interface TopBarProps {
  companyName: string;
  botName: string;
  activeTab: StudioTab;
  drawerOpen: boolean;
  onSelectTab: (tab: StudioTab) => void;
  user: User | null;
  authBusy: boolean;
  onSignIn: () => void;
  onSignOut: () => void;
}

const NAV_ITEMS: Array<{ id: StudioTab; label: string }> = [
  { id: 'operations', label: 'Operations' },
  { id: 'inventory', label: 'Inventory' },
  { id: 'systems', label: 'Pempam Apps' },
  { id: 'calendar', label: 'Calendar' },
  { id: 'customize', label: 'Customize' },
];

export const TopBar: React.FC<TopBarProps> = ({
  companyName,
  botName,
  activeTab,
  drawerOpen,
  onSelectTab,
  user,
  authBusy,
  onSignIn,
  onSignOut,
}) => {
  return (
    <header className="pointer-events-auto relative z-20 flex h-14 items-center justify-between gap-8 border-b border-slate-200/80 bg-white/95 px-5 text-slate-900">
      {/* Zone 1: Single-line Brand Wordmark */}
      <a
        href="#stage"
        onClick={(e) => {
          e.preventDefault();
          onSelectTab('operations');
        }}
        className="font-display whitespace-nowrap shrink-0 text-base font-bold tracking-tight text-slate-900"
      >
        {companyName} · {botName}
      </a>

      {/* Zone 2: 4 single-line navigation links */}
      <nav
        aria-label="Workspace sections"
        className="hidden items-center gap-6 md:flex"
      >
        {NAV_ITEMS.map((item) => {
          const isActive = drawerOpen && activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`whitespace-nowrap shrink-0 cursor-pointer border-b-2 py-1 text-sm font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-600 ${
                isActive
                  ? 'border-blue-600 text-slate-950'
                  : 'border-transparent text-slate-600 hover:text-slate-950'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: 1 Primary Action */}
      <div className="flex shrink-0 items-center">
        {user ? (
          <button
            type="button"
            onClick={onSignOut}
            disabled={authBusy}
            className="whitespace-nowrap shrink-0 cursor-pointer rounded-lg border border-slate-300 bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-slate-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 disabled:opacity-60"
          >
            {user.displayName ? `${user.displayName.split(' ')[0]} · Sign out` : 'Sign out'}
          </button>
        ) : (
          <button
            type="button"
            onClick={onSignIn}
            disabled={authBusy}
            className="gsi-material-button"
          >
            <div className="gsi-material-button-content-wrapper">
              <div className="gsi-material-button-icon">
                <svg
                  version="1.1"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 48 48"
                  style={{ display: 'block' }}
                >
                  <path
                    fill="#EA4335"
                    d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                  />
                  <path
                    fill="#34A853"
                    d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                  />
                </svg>
              </div>
              <span>{authBusy ? 'Signing in...' : 'Sign in with Google'}</span>
            </div>
          </button>
        )}
      </div>
    </header>
  );
};
