import React from 'react';
import { CalendarPlus } from 'lucide-react';
import {
  InventoryHealthRow,
  PendingCalendarAction,
} from '../../types/operations';
import { formatPhp } from '../../utils/operationsEngine';

interface InventoryTabProps {
  rows: InventoryHealthRow[];
  onProposeRestockEvent: (action: PendingCalendarAction) => void;
}

export const InventoryTab: React.FC<InventoryTabProps> = ({
  rows,
  onProposeRestockEvent,
}) => {
  const handleScheduleRestock = (item: InventoryHealthRow) => {
    const tomorrow = new Date(Date.now() + 86_400_000);
    tomorrow.setHours(9, 0, 0, 0);
    const end = new Date(tomorrow.getTime() + 30 * 60_000);

    onProposeRestockEvent({
      summary: `Restock PO: ${item.canonicalName} (${item.recommendedReorderQty} units)`,
      startIso: tomorrow.toISOString(),
      endIso: end.toISOString(),
      location: 'Pempam Smart Stockroom — Manila',
      description: `SKU ${item.canonicalSku} is ${item.status} (${item.actualStock} units left, velocity ${item.dailyVelocity}/day). Recommended reorder: ${item.recommendedReorderQty} units at cost ${formatPhp(item.unitCostPhp)}/unit.`,
    });
  };

  if (rows.length === 0) {
    return (
      <div className="py-8 text-sm text-slate-600">
        No inventory items loaded yet. Load the Pempam sample batch in the
        Operations tab to inspect live stock reconciliation and restock
        forecasts.
      </div>
    );
  }

  return (
    <div className="space-y-4 text-slate-900">
      <div className="flex items-baseline justify-between gap-2">
        <h2 className="font-display text-base font-bold">
          Smart Inventory & Restock Monitor
        </h2>
        <span className="font-mono-tabular text-xs text-slate-500">
          {rows.length} canonical SKUs
        </span>
      </div>

      <div className="space-y-2.5">
        {rows.map((item) => {
          const statusColor =
            item.status === 'CRITICAL'
              ? 'text-rose-700'
              : item.status === 'LOW_STOCK'
                ? 'text-amber-700'
                : item.status === 'OVERSTOCK'
                  ? 'text-indigo-700'
                  : 'text-emerald-700';

          return (
            <div
              key={item.canonicalSku}
              className="rounded-lg border border-slate-200 p-3 text-xs"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold text-slate-900">
                    {item.canonicalName}
                  </div>
                  <div className="font-mono-tabular mt-0.5 text-slate-500">
                    {item.canonicalSku} · {item.category}
                  </div>
                </div>
                <span
                  className={`font-mono-tabular shrink-0 font-bold ${statusColor}`}
                >
                  {item.status}
                </span>
              </div>

              <div className="font-mono-tabular mt-2.5 grid grid-cols-3 gap-2 border-t border-slate-100 pt-2 text-[11px] text-slate-700">
                <div>
                  <span className="text-slate-500">Actual / Exp: </span>
                  <span className="font-semibold text-slate-900">
                    {item.actualStock} / {item.expectedEndingStock}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500">Run-Out: </span>
                  <span className="font-semibold text-slate-900">
                    {item.daysUntilStockout !== null
                      ? `${item.daysUntilStockout}d`
                      : 'No sales'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500">Margin: </span>
                  <span
                    className={`font-semibold ${
                      item.lowMarginFlag ? 'text-rose-600' : 'text-slate-900'
                    }`}
                  >
                    {item.marginPct !== null ? `${item.marginPct}%` : '—'}
                  </span>
                </div>
              </div>

              {item.recommendedReorderQty > 0 && (
                <div className="mt-2.5 flex items-center justify-between gap-2 border-t border-slate-100 pt-2">
                  <span className="font-mono-tabular font-semibold text-amber-800">
                    Reorder {item.recommendedReorderQty} units (
                    {formatPhp(item.recommendedReorderQty * item.unitCostPhp)})
                  </span>
                  <button
                    type="button"
                    onClick={() => handleScheduleRestock(item)}
                    className="whitespace-nowrap shrink-0 flex cursor-pointer items-center gap-1 rounded-md border border-slate-300 bg-white px-2.5 py-1 text-[11px] font-semibold text-slate-800 hover:bg-slate-50"
                  >
                    <CalendarPlus className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Schedule Restock</span>
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
