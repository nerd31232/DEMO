import React, { useState } from 'react';
import { Calendar, RefreshCw } from 'lucide-react';
import {
  CalendarEventItem,
  PendingCalendarAction,
} from '../../types/operations';

interface CalendarTabProps {
  hasToken: boolean;
  events: CalendarEventItem[];
  loading: boolean;
  errorMsg: string | null;
  onSignIn: () => void;
  onRefreshEvents: () => void;
  onProposeEvent: (action: PendingCalendarAction) => void;
}

export const CalendarTab: React.FC<CalendarTabProps> = ({
  hasToken,
  events,
  loading,
  errorMsg,
  onSignIn,
  onRefreshEvents,
  onProposeEvent,
}) => {
  const [summary, setSummary] = useState('Pempam Stock Audit & POS Reconciliation');
  const [dateStr, setDateStr] = useState('2026-11-24');
  const [timeStr, setTimeStr] = useState('09:30');
  const [location, setLocation] = useState('Pempam Manila Operations');
  const [description, setDescription] = useState(
    'Review PemBot 3D restock orders, low-margin SKUs, and repaired POS logs.'
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!summary.trim() || !dateStr || !timeStr) return;
    const start = new Date(`${dateStr}T${timeStr}:00+08:00`);
    const end = new Date(start.getTime() + 45 * 60_000);
    onProposeEvent({
      summary: summary.trim(),
      startIso: start.toISOString(),
      endIso: end.toISOString(),
      location: location.trim() || 'Pempam Operations',
      description: description.trim(),
    });
  };

  if (!hasToken) {
    return (
      <div className="space-y-4 py-4 text-slate-900">
        <h2 className="font-display text-base font-bold">
          Google Calendar Sync
        </h2>
        <p className="text-sm leading-relaxed text-slate-600">
          Sign in with Google to view your upcoming Pempam operations schedule
          and create restock or audit reminders with explicit confirmation.
        </p>
        <button
          type="button"
          onClick={onSignIn}
          className="gsi-material-button"
        >
          <div className="gsi-material-button-content-wrapper">
            <div className="gsi-material-button-icon">
              <svg
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 48 48"
                style={{ display: 'block' }}
              >
                <path
                  fill="#EA4335"
                  d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                />
                <path
                  fill="#4285F4"
                  d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                />
                <path
                  fill="#FBBC05"
                  d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                />
                <path
                  fill="#34A853"
                  d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                />
              </svg>
            </div>
            <span>Sign in with Google</span>
          </div>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6 text-slate-900">
      <section>
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-display text-base font-bold">
            Upcoming Operations Schedule
          </h2>
          <button
            type="button"
            onClick={onRefreshEvents}
            disabled={loading}
            className="whitespace-nowrap shrink-0 flex cursor-pointer items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-700 disabled:opacity-60"
          >
            <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{loading ? 'Refreshing...' : 'Refresh'}</span>
          </button>
        </div>

        {errorMsg && (
          <p className="mt-2 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-800">
            {errorMsg}
          </p>
        )}

        {events.length === 0 ? (
          <p className="mt-3 text-xs text-slate-500">
            No upcoming events found on your primary Google Calendar.
          </p>
        ) : (
          <ul className="mt-3 space-y-2">
            {events.map((ev) => (
              <li
                key={ev.id}
                className="rounded-lg border border-slate-200 p-3 text-xs"
              >
                <div className="font-semibold text-slate-900">{ev.summary}</div>
                <div className="font-mono-tabular mt-1 text-slate-600">
                  {ev.start
                    ? new Date(ev.start).toLocaleString('en-PH', {
                        timeZone: 'Asia/Manila',
                      })
                    : 'All day'}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="border-t border-slate-200 pt-5">
        <h3 className="font-display text-sm font-bold">
          Schedule Restock or Audit Event
        </h3>
        <form onSubmit={handleSubmit} className="mt-3 space-y-3 text-xs">
          <div>
            <label
              htmlFor="cal-summary"
              className="block font-medium text-slate-700"
            >
              Event Title
            </label>
            <input
              id="cal-summary"
              type="text"
              required
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:border-blue-600 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="cal-date"
                className="block font-medium text-slate-700"
              >
                Date (Manila)
              </label>
              <input
                id="cal-date"
                type="date"
                required
                value={dateStr}
                onChange={(e) => setDateStr(e.target.value)}
                className="font-mono-tabular mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="cal-time"
                className="block font-medium text-slate-700"
              >
                Time (UTC+8)
              </label>
              <input
                id="cal-time"
                type="time"
                required
                value={timeStr}
                onChange={(e) => setTimeStr(e.target.value)}
                className="font-mono-tabular mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="cal-location"
              className="block font-medium text-slate-700"
            >
              Location
            </label>
            <input
              id="cal-location"
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:border-blue-600 focus:outline-none"
            />
          </div>

          <div>
            <label
              htmlFor="cal-desc"
              className="block font-medium text-slate-700"
            >
              Notes
            </label>
            <textarea
              id="cal-desc"
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:border-blue-600 focus:outline-none"
            />
          </div>

          <button
            type="submit"
            className="flex cursor-pointer items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-500"
          >
            <Calendar className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Review & Schedule Event</span>
          </button>
        </form>
      </section>
    </div>
  );
};
