import React, { useState } from 'react';
import {
  CheckCircle2,
  Download,
  Lock,
  ShieldAlert,
  Sparkles,
  Zap,
} from 'lucide-react';
import {
  BotCustomizationProfile,
  OperationalAnalysisResult,
} from '../../types/operations';
import { formatPhp } from '../../utils/operationsEngine';
import { StoredAuditRun } from '../../lib/firestoreSync';

interface OperationsTabProps {
  profile: BotCustomizationProfile;
  analysis: OperationalAnalysisResult | null;
  rawInput: string;
  onChangeRawInput: (val: string) => void;
  thinkingMode: 'fast' | 'deep';
  onChangeThinkingMode: (mode: 'fast' | 'deep') => void;
  busy: boolean;
  errorMsg: string | null;
  onLoadSample: () => void;
  onSyncLiveApps: () => void;
  onOpenSystems: () => void;
  liveStatusLabel: string;
  onRunCommandOrAudit: (overrideText?: string) => void;
  onConfirmFix: () => void;
  voiceTranscripts: Array<{ role: 'user' | 'bot'; text: string }>;
  storedAudits: StoredAuditRun[];
}

export const OperationsTab: React.FC<OperationsTabProps> = ({
  profile,
  analysis,
  rawInput,
  onChangeRawInput,
  thinkingMode,
  onChangeThinkingMode,
  busy,
  errorMsg,
  onLoadSample,
  onSyncLiveApps,
  onOpenSystems,
  liveStatusLabel,
  onRunCommandOrAudit,
  onConfirmFix,
  voiceTranscripts,
  storedAudits,
}) => {
  const [showJsonPatch, setShowJsonPatch] = useState(false);

  const handleDownloadRepaired = () => {
    if (!analysis?.repairedPayload) return;
    const exportPayload = {
      auditChangeLog: analysis.auditChangeLog,
      bot3dState: analysis.bot3dState,
      repairedData: analysis.repairedPayload,
    };
    const blob = new Blob([JSON.stringify(exportPayload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pempam-repaired-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 text-slate-900">
      {/* Command & Data Input Composer */}
      <section aria-labelledby="composer-heading">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 id="composer-heading" className="font-display text-base font-bold">
            Operations Console & Command Input
          </h2>
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={onSyncLiveApps}
              className="whitespace-nowrap shrink-0 cursor-pointer text-xs font-semibold text-emerald-700 hover:text-emerald-800 hover:underline"
            >
              Sync Live Pempam Apps
            </button>
            <button
              type="button"
              onClick={onLoadSample}
              className="whitespace-nowrap shrink-0 cursor-pointer text-xs font-semibold text-blue-600 hover:text-blue-700 hover:underline"
            >
              Load Sample Batch
            </button>
          </div>
        </div>

        <div className="mt-1.5 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-[11px] text-slate-600">
          <span>{liveStatusLabel}</span>
          <button
            type="button"
            onClick={onOpenSystems}
            className="whitespace-nowrap shrink-0 cursor-pointer font-semibold text-slate-900 hover:underline"
          >
            Open POS & Repair Desk
          </button>
        </div>

        <label htmlFor="ops-command-input" className="sr-only">
          Paste POS JSON, CSV, stock logs, or customization command
        </label>
        <textarea
          id="ops-command-input"
          value={rawInput}
          onChange={(e) => onChangeRawInput(e.target.value)}
          rows={4}
          placeholder='Paste JSON/CSV receipts, ask an audit question, type "CONFIRM FIX", or run "/customize Rename yourself to Atlas, wear a formal barong"'
          className="mt-2 w-full rounded-lg border border-slate-300 bg-slate-50 p-3 text-xs leading-relaxed text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:bg-white focus:outline-none"
        />

        <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2">
          {/* Thinking / Latency Mode Switcher */}
          <div
            role="group"
            aria-label="Reasoning latency mode"
            className="flex items-center gap-1 rounded-lg bg-slate-100 p-1"
          >
            <button
              type="button"
              onClick={() => onChangeThinkingMode('fast')}
              className={`whitespace-nowrap shrink-0 flex cursor-pointer items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium transition-colors ${
                thinkingMode === 'fast'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Zap className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Low-Latency</span>
            </button>
            <button
              type="button"
              onClick={() => onChangeThinkingMode('deep')}
              className={`whitespace-nowrap shrink-0 flex cursor-pointer items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium transition-colors ${
                thinkingMode === 'deep'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
              <span>High Thinking</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => onRunCommandOrAudit()}
            disabled={busy}
            className="whitespace-nowrap shrink-0 cursor-pointer rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-slate-800 disabled:opacity-60"
          >
            {busy ? 'Analyzing...' : 'Run Audit & AI'}
          </button>
        </div>

        {errorMsg && (
          <p
            role="alert"
            className="mt-2 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-800"
          >
            {errorMsg}
          </p>
        )}
      </section>

      {/* Live Voice Transcripts (only when populated) */}
      {voiceTranscripts.length > 0 && (
        <section className="border-t border-slate-200 pt-4">
          <h3 className="font-display text-sm font-bold text-slate-900">
            Live Voice Transcript
          </h3>
          <div className="mt-2 max-h-32 space-y-1.5 overflow-y-auto text-xs">
            {voiceTranscripts.map((t, i) => (
              <div key={i} className="text-slate-700">
                <span className="font-semibold text-slate-900">
                  {t.role === 'user' ? 'You' : profile.botName}:{' '}
                </span>
                <span>{t.text}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {!analysis ? (
        <div className="border-t border-slate-200 pt-6 text-sm text-slate-600">
          Load the Pempam sample batch or paste your POS/inventory data above to
          generate a verified operational briefing.
        </div>
      ) : (
        <>
          {/* 1. 3D Office Scene & Bot Status */}
          <section className="border-t border-slate-200 pt-5">
            <div className="flex items-baseline justify-between gap-2">
              <h3 className="font-display text-sm font-bold text-slate-900">
                1. 3D Office Scene & Bot Status
              </h3>
              <span className="text-xs text-slate-500">
                {profile.botName} · {analysis.thinkingMode === 'fast' ? 'Fast' : 'High Thinking'}
                {analysis.modelUsed ? ` · ${analysis.modelUsed}` : ''}
              </span>
            </div>
            <p className="mt-1.5 text-sm leading-relaxed text-slate-700">
              {analysis.sceneCue}
            </p>
            {analysis.aiNarrative && (
              <p className="mt-2 text-sm leading-relaxed text-slate-900">
                {analysis.aiNarrative}
              </p>
            )}
          </section>

          {/* 2. Action Required Today */}
          <section className="border-t border-slate-200 pt-5">
            <h3 className="font-display text-sm font-bold text-slate-900">
              2. Action Required Today
            </h3>
            {analysis.actionRequiredToday.length === 0 ? (
              <p className="mt-2 text-sm text-emerald-700">
                All stock levels and financial reconciliations are clear.
              </p>
            ) : (
              <ul className="mt-2 space-y-2 text-xs leading-relaxed text-slate-800">
                {analysis.actionRequiredToday.map((alert, i) => (
                  <li
                    key={i}
                    className="rounded-lg border border-amber-200 bg-amber-50/70 px-3 py-2 font-medium text-amber-950"
                  >
                    {alert}
                  </li>
                ))}
              </ul>
            )}
          </section>

          {/* 3. Sales Performance Summary */}
          <section className="border-t border-slate-200 pt-5">
            <div className="flex items-baseline justify-between gap-2">
              <h3 className="font-display text-sm font-bold text-slate-900">
                3. Sales Performance Summary
              </h3>
              <span className="text-xs text-slate-500">
                Currency: PHP · Asia/Manila
              </span>
            </div>

            <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
              <div className="rounded-lg border border-slate-200 p-3">
                <div className="text-xs text-slate-500">Net Revenue</div>
                <div className="font-mono-tabular mt-1 text-base font-bold text-slate-900">
                  {formatPhp(analysis.salesSummary.netRevenuePhp)}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 p-3">
                <div className="text-xs text-slate-500">Gross / Discounts</div>
                <div className="font-mono-tabular mt-1 text-sm font-semibold text-slate-900">
                  {formatPhp(analysis.salesSummary.grossSalesPhp)}
                </div>
                <div className="font-mono-tabular text-xs text-slate-500">
                  -{formatPhp(analysis.salesSummary.discountsPhp)}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 p-3">
                <div className="text-xs text-slate-500">
                  Txns / AOV
                  {analysis.salesSummary.wowTrendPct !== null
                    ? ` · WoW ${analysis.salesSummary.wowTrendPct > 0 ? '+' : ''}${analysis.salesSummary.wowTrendPct}%`
                    : ''}
                </div>
                <div className="font-mono-tabular mt-1 text-sm font-semibold text-slate-900">
                  {analysis.salesSummary.totalTransactions} ·{' '}
                  {formatPhp(analysis.salesSummary.averageOrderValuePhp)}
                </div>
              </div>
            </div>

            {/* Top 5 Products Table */}
            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="py-1.5 font-medium">Product</th>
                    <th className="py-1.5 text-right font-medium">Units</th>
                    <th className="py-1.5 text-right font-medium">Revenue</th>
                    <th className="py-1.5 text-right font-medium">Margin</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {analysis.salesSummary.topProducts.map((p) => (
                    <tr key={p.canonicalSku}>
                      <td className="py-2 font-medium text-slate-900">
                        {p.canonicalName}
                      </td>
                      <td className="font-mono-tabular py-2 text-right text-slate-700">
                        {p.unitsSold}
                      </td>
                      <td className="font-mono-tabular py-2 text-right font-semibold text-slate-900">
                        {formatPhp(p.revenuePhp)}
                      </td>
                      <td
                        className={`font-mono-tabular py-2 text-right font-semibold ${
                          p.lowMarginFlag ? 'text-rose-600' : 'text-emerald-700'
                        }`}
                      >
                        {p.marginPct !== null ? `${p.marginPct}%` : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Payment Split & Slow Movers */}
            <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
              <span className="font-semibold text-slate-800">Payments:</span>
              {analysis.salesSummary.paymentBreakdown.map((pm) => (
                <span key={pm.method} className="font-mono-tabular">
                  {pm.method}: {formatPhp(pm.totalPhp)} ({pm.sharePct}%)
                </span>
              ))}
            </div>
            {analysis.salesSummary.slowMovers.length > 0 && (
              <p className="mt-1.5 text-xs text-slate-600">
                <span className="font-semibold text-slate-800">
                  Zero-Sale / Slow Movers:{' '}
                </span>
                {analysis.salesSummary.slowMovers.join(', ')}
              </p>
            )}
          </section>

          {/* 4. Inventory Health Snapshot */}
          <section className="border-t border-slate-200 pt-5">
            <h3 className="font-display text-sm font-bold text-slate-900">
              4. Inventory Health & Restock Forecast
            </h3>
            <p className="mt-1 text-xs text-slate-600">
              {
                analysis.inventoryHealth.filter((i) => i.status === 'CRITICAL')
                  .length
              }{' '}
              CRITICAL ·{' '}
              {
                analysis.inventoryHealth.filter((i) => i.status === 'LOW_STOCK')
                  .length
              }{' '}
              LOW STOCK ·{' '}
              {
                analysis.inventoryHealth.filter((i) => i.status === 'HEALTHY')
                  .length
              }{' '}
              HEALTHY ·{' '}
              {
                analysis.inventoryHealth.filter((i) => i.status === 'OVERSTOCK')
                  .length
              }{' '}
              OVERSTOCK (open Inventory tab for full SKU table & Calendar
              scheduling)
            </p>
          </section>

          {/* 5. Error Fixer, Quarantine & Security Shield */}
          <section className="border-t border-slate-200 pt-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-display text-sm font-bold text-slate-900">
                5. Error Fixer & Quarantine Log
              </h3>
              <span className="text-xs text-slate-500">
                Redacted: {analysis.redactedSecretsCount} · Injections Blocked:{' '}
                {analysis.promptInjectionsBlocked}
              </span>
            </div>

            {analysis.normalizations.length > 0 && (
              <div className="mt-2 rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-700">
                <span className="font-semibold text-slate-900">
                  Entity Normalization:{' '}
                </span>
                {analysis.normalizations.map((n) => (
                  <span key={n.canonicalSku}>
                    Merged [{n.mergedVariants.join(' / ')}] into{' '}
                    <span className="font-mono-tabular font-semibold">
                      {n.canonicalSku}
                    </span>
                  </span>
                ))}
              </div>
            )}

            <div className="mt-3 space-y-2">
              {analysis.errors.map((err) => (
                <div
                  key={err.errorId}
                  className="rounded-lg border border-slate-200 p-2.5 text-xs"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono-tabular font-bold text-slate-900">
                      {err.errorId} · {err.issueType}
                    </span>
                    <span className="font-mono-tabular font-semibold text-amber-700">
                      {err.severity}
                    </span>
                  </div>
                  <div className="mt-1 text-slate-600">
                    {err.recordRef} — {err.rootCause}
                  </div>
                  <div className="font-mono-tabular mt-1.5 rounded bg-slate-100 px-2 py-1 text-[11px] text-slate-800">
                    {err.beforeValue} → {err.afterValue}
                  </div>
                </div>
              ))}
            </div>

            {analysis.quarantine.length > 0 && (
              <div className="mt-3 rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs text-rose-950">
                <div className="flex items-center gap-1.5 font-bold">
                  <ShieldAlert className="h-4 w-4" aria-hidden="true" />
                  <span>Quarantine Zone ({analysis.quarantine.length})</span>
                </div>
                {analysis.quarantine.map((q) => (
                  <div key={q.quarantineId} className="mt-1.5">
                    <span className="font-mono-tabular font-semibold">
                      {q.quarantineId} ({q.recordRef}):
                    </span>{' '}
                    {q.reason}
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* 6. Two-Step Write Lock & Safe JSON Patch */}
          <section className="border-t border-slate-200 pt-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-display text-sm font-bold text-slate-900">
                6. Safe JSON Patch & Two-Step Write Lock
              </h3>
              <span className="font-mono-tabular text-xs font-semibold text-slate-700">
                {analysis.writeLockStatus}
              </span>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              {analysis.writeLockStatus === 'AWAITING_CONFIRM_FIX' ? (
                <button
                  type="button"
                  onClick={onConfirmFix}
                  className="whitespace-nowrap shrink-0 flex cursor-pointer items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-emerald-500"
                >
                  <Lock className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>CONFIRM FIX</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleDownloadRepaired}
                  className="whitespace-nowrap shrink-0 flex cursor-pointer items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-500"
                >
                  <Download className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Download Repaired JSON</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setShowJsonPatch((v) => !v)}
                className="whitespace-nowrap shrink-0 cursor-pointer rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                {showJsonPatch ? 'Hide JSON Patch' : 'Inspect JSON State'}
              </button>
            </div>

            {analysis.auditChangeLog.length > 0 && (
              <div className="mt-3 rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-xs text-emerald-950">
                <div className="flex items-center gap-1.5 font-bold">
                  <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                  <span>Audit Change Log</span>
                </div>
                {analysis.auditChangeLog.map((entry, idx) => (
                  <p key={idx} className="mt-1">
                    <span className="font-mono-tabular font-semibold">
                      [{entry.timestampManila}]
                    </span>{' '}
                    {entry.action} ({entry.errorIds.join(', ')}) — {entry.note}
                  </p>
                ))}
              </div>
            )}

            {showJsonPatch && (
              <pre className="font-mono-tabular mt-3 max-h-56 overflow-auto rounded-lg bg-slate-900 p-3 text-[11px] text-slate-100">
                {JSON.stringify(
                  {
                    bot_3d_state: analysis.bot3dState,
                    audit_change_log: analysis.auditChangeLog,
                    repaired_payload: analysis.repairedPayload,
                  },
                  null,
                  2
                )}
              </pre>
            )}
          </section>
        </>
      )}

      {/* Saved Firestore Audit History */}
      {storedAudits.length > 0 && (
        <section className="border-t border-slate-200 pt-5">
          <h3 className="font-display text-sm font-bold text-slate-900">
            Recent Cloud Audit History
          </h3>
          <ul className="mt-2 space-y-1.5 text-xs">
            {storedAudits.slice(0, 5).map((a) => (
              <li
                key={a.id}
                className="flex items-center justify-between gap-2 border-b border-slate-100 py-1.5"
              >
                <span className="truncate font-medium text-slate-800">
                  {a.title}
                </span>
                <span className="font-mono-tabular shrink-0 text-slate-600">
                  {formatPhp(a.netRevenuePhp)} · {a.writeLockStatus}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
};
