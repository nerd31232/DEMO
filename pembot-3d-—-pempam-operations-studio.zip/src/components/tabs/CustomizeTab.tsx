import React from 'react';
import {
  BotCustomizationProfile,
  OfficeTheme,
  OutfitStyle,
  PersonalityMode,
} from '../../types/operations';

interface CustomizeTabProps {
  profile: BotCustomizationProfile;
  onChangeProfile: (next: BotCustomizationProfile) => void;
  isSignedIn: boolean;
  saving: boolean;
  onSaveCloud: () => void;
}

const ACCENT_SWATCHES = [
  { hex: '#2563EB', name: 'Studio Blue' },
  { hex: '#059669', name: 'Emerald' },
  { hex: '#D97706', name: 'Amber Gold' },
  { hex: '#0891B2', name: 'Cyber Cyan' },
  { hex: '#7C3AED', name: 'Royal Violet' },
];

export const CustomizeTab: React.FC<CustomizeTabProps> = ({
  profile,
  onChangeProfile,
  isSignedIn,
  saving,
  onSaveCloud,
}) => {
  const update = <K extends keyof BotCustomizationProfile>(
    key: K,
    value: BotCustomizationProfile[K]
  ) => {
    onChangeProfile({ ...profile, [key]: value });
  };

  return (
    <div className="space-y-5 text-xs text-slate-900">
      <div className="flex items-baseline justify-between gap-2">
        <h2 className="font-display text-base font-bold">
          Customize 3D Agent & Office
        </h2>
        <span className="text-slate-500">Live 3D Sync</span>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <label
            htmlFor="custom-bot-name"
            className="block font-medium text-slate-700"
          >
            Bot Name
          </label>
          <input
            id="custom-bot-name"
            type="text"
            maxLength={60}
            value={profile.botName}
            onChange={(e) => update('botName', e.target.value)}
            className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:border-blue-600 focus:outline-none"
          />
        </div>
        <div>
          <label
            htmlFor="custom-company"
            className="block font-medium text-slate-700"
          >
            Company / Workspace
          </label>
          <input
            id="custom-company"
            type="text"
            maxLength={80}
            value={profile.companyName}
            onChange={(e) => update('companyName', e.target.value)}
            className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:border-blue-600 focus:outline-none"
          />
        </div>
      </div>

      <div>
        <label
          htmlFor="custom-office-theme"
          className="block font-medium text-slate-700"
        >
          3D Office Environment Theme
        </label>
        <select
          id="custom-office-theme"
          value={profile.officeTheme}
          onChange={(e) =>
            update('officeTheme', e.target.value as OfficeTheme)
          }
          className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 focus:border-blue-600 focus:outline-none"
        >
          <option value="daylight_studio">Daylight Studio</option>
          <option value="cyberpunk_night">Cyberpunk Night Shift</option>
          <option value="minimalist_warehouse">Minimalist Warehouse</option>
        </select>
      </div>

      <div>
        <label
          htmlFor="custom-outfit"
          className="block font-medium text-slate-700"
        >
          Character Outfit / Chassis
        </label>
        <select
          id="custom-outfit"
          value={profile.outfitStyle}
          onChange={(e) =>
            update('outfitStyle', e.target.value as OutfitStyle)
          }
          className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 focus:border-blue-600 focus:outline-none"
        >
          <option value="standard_chassis">Standard Pempam Chassis</option>
          <option value="formal_barong">Formal Barong Edition</option>
          <option value="cyber_visor">Diagnostic Cyber Visor</option>
          <option value="executive_slate">Executive Slate Armor</option>
        </select>
      </div>

      <div>
        <label
          htmlFor="custom-personality"
          className="block font-medium text-slate-700"
        >
          Personality & Voice Tone
        </label>
        <select
          id="custom-personality"
          value={profile.personality}
          onChange={(e) =>
            update('personality', e.target.value as PersonalityMode)
          }
          className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 focus:border-blue-600 focus:outline-none"
        >
          <option value="friendly_coworker">Friendly Co-Worker</option>
          <option value="strict_auditor">Strict Auditor</option>
          <option value="executive_briefing">Executive Briefing</option>
        </select>
      </div>

      <div>
        <span className="block font-medium text-slate-700">
          LED Visor & Trim Accent
        </span>
        <div className="mt-2 flex items-center gap-2.5">
          {ACCENT_SWATCHES.map((swatch) => (
            <button
              key={swatch.hex}
              type="button"
              aria-label={`Select ${swatch.name}`}
              onClick={() => update('accentColor', swatch.hex)}
              style={{ backgroundColor: swatch.hex }}
              className={`h-7 w-7 cursor-pointer rounded-full border-2 transition-transform ${
                profile.accentColor.toUpperCase() === swatch.hex
                  ? 'scale-110 border-slate-950'
                  : 'border-white'
              }`}
            />
          ))}
        </div>
      </div>

      {isSignedIn && (
        <div className="border-t border-slate-200 pt-4">
          <button
            type="button"
            onClick={onSaveCloud}
            disabled={saving}
            className="cursor-pointer rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-60"
          >
            {saving ? 'Saving to Cloud...' : 'Save Profile to Firestore'}
          </button>
        </div>
      )}
    </div>
  );
};
