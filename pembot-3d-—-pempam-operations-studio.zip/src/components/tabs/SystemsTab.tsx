import React, { useState } from 'react';
import {
  Bot,
  FileText,
  RefreshCw,
  ShoppingCart,
} from 'lucide-react';
import { formatPhp } from '../../utils/operationsEngine';
import { LivePempamSnapshot } from '../../utils/pempamAppsBridge';

export type EmbeddedAppId = 'pos_glonext' | 'repair_receipt';

interface SystemsTabProps {
  snapshot: LivePempamSnapshot;
  iframeNonce: number;
  onRefreshSnapshot: () => void;
  onSyncToAgent: () => void;
}

const APP_SOURCES: Record<
  EmbeddedAppId,
  { title: string; subtitle: string; src: string }
> = {
  pos_glonext: {
    title: 'PEMPAM Sales Monitoring (GloNext)',
    subtitle: 'POS, inventory stock movements, pricing tiers & reports',
    src: '/assets/aistudio/pempam-enhanced-2_951ead79.html',
  },
  repair_receipt: {
    title: 'Pempam Toner & Ink — Repair Receipt',
    subtitle: 'Service intake, parts billing, claims & dual copy print',
    src: '/assets/aistudio/gemini-code-1795427393790_d75b69d3.html',
  },
};

export const SystemsTab: React.FC<SystemsTabProps> = ({
  snapshot,
  iframeNonce,
  onRefreshSnapshot,
  onSyncToAgent,
}) => {
  const [activeApp, setActiveApp] = useState<EmbeddedAppId>('pos_glonext');
  const m = snapshot.metrics;
  const current = APP_SOURCES[activeApp];

  return (
    <div className="flex h-full flex-col gap-3 text-slate-900">
      {/* Live AI Agent Bridge Header */}
      <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="font-display text-sm font-bold text-slate-900">
              Connected Pempam Systems & AI Agent Bridge
            </h2>
            <p className="text-xs text-slate-600">
              Your POS and Repair Desk share live browser storage with PemBot 3D for instant auditing and CONFIRM FIX sync.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onRefreshSnapshot}
              className="whitespace-nowrap shrink-0 flex cursor-pointer items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100"
            >
              <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Refresh Readout</span>
            </button>

            <button
              type="button"
              onClick={onSyncToAgent}
              className="whitespace-nowrap shrink-0 flex cursor-pointer items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-700"
            >
              <Bot className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Sync & Audit in PemBot 3D</span>
            </button>
          </div>
        </div>

        {/* Live Telemetry Summary Strip */}
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <div className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              GloNext POS SKUs
            </div>
            <div className="font-mono-tabular text-xs font-bold text-slate-900">
              {snapshot.hasGloNextData
                ? `${m.posProductsCount} SKUs · ${m.posLowStockCount} low`
                : 'Open POS to initialize'}
            </div>
          </div>

          <div className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              POS Completed Sales
            </div>
            <div className="font-mono-tabular text-xs font-bold text-slate-900">
              {snapshot.hasGloNextData
                ? `${m.posCompletedSalesCount} receipts · ${m.posCustomersCount} clients`
                : 'No live sales yet'}
            </div>
          </div>

          <div className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              Repair Tickets
            </div>
            <div className="font-mono-tabular text-xs font-bold text-slate-900">
              {snapshot.hasRepairData
                ? `${m.repairPendingCount} pending · ${m.repairClaimedCount} claimed`
                : 'No saved repairs yet'}
            </div>
          </div>

          <div className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              Pending Claim Value
            </div>
            <div className="font-mono-tabular text-xs font-bold text-amber-700">
              {formatPhp(m.repairPendingValuePhp)}
              {m.repairOverdue30dCount + m.repairOverdue90dCount > 0
                ? ` (${m.repairOverdue30dCount + m.repairOverdue90dCount} overdue)`
                : ''}
            </div>
          </div>
        </div>
      </div>

      {/* App Switcher Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div role="tablist" aria-label="Embedded Pempam Tools" className="flex gap-1.5">
          <button
            type="button"
            role="tab"
            aria-selected={activeApp === 'pos_glonext'}
            onClick={() => setActiveApp('pos_glonext')}
            className={`whitespace-nowrap shrink-0 flex cursor-pointer items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              activeApp === 'pos_glonext'
                ? 'bg-slate-900 text-white'
                : 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-100'
            }`}
          >
            <ShoppingCart className="h-3.5 w-3.5" aria-hidden="true" />
            <span>GloNext Sales POS</span>
          </button>

          <button
            type="button"
            role="tab"
            aria-selected={activeApp === 'repair_receipt'}
            onClick={() => setActiveApp('repair_receipt')}
            className={`whitespace-nowrap shrink-0 flex cursor-pointer items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              activeApp === 'repair_receipt'
                ? 'bg-slate-900 text-white'
                : 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-100'
            }`}
          >
            <FileText className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Repair & Service Receipt</span>
          </button>
        </div>

        <span className="text-[11px] font-medium text-slate-500">
          {current.subtitle}
        </span>
      </div>

      {/* Embedded Live HTML Tool Frame */}
      <div className="min-h-[540px] flex-1 overflow-hidden rounded-xl border border-slate-300 bg-white shadow-inner">
        <iframe
          key={`${activeApp}-${iframeNonce}`}
          src={current.src}
          title={current.title}
          onLoad={onRefreshSnapshot}
          className="h-full min-h-[540px] w-full border-0"
        />
      </div>
    </div>
  );
};
