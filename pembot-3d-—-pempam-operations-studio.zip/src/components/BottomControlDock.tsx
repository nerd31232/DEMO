import React from 'react';
import {
  Camera,
  ChevronDown,
  ChevronUp,
  Mic,
  MicOff,
  PanelRightClose,
  PanelRightOpen,
} from 'lucide-react';
import {
  BotAnimationState,
  OfficeTheme,
} from '../types/operations';
import { CameraPreset } from '../three/OfficeViewport';

interface BottomControlDockProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
  officeTheme: OfficeTheme;
  onChangeTheme: (theme: OfficeTheme) => void;
  animationState: BotAnimationState;
  onChangeAnimation: (anim: BotAnimationState) => void;
  cameraPreset: CameraPreset;
  onChangeCamera: (preset: CameraPreset) => void;
  voiceStatus: 'idle' | 'connecting' | 'connected' | 'error';
  onToggleVoice: () => void;
  drawerOpen: boolean;
  wideDrawer?: boolean;
  onToggleDrawer: () => void;
}

const THEME_OPTIONS: Array<{ id: OfficeTheme; label: string }> = [
  { id: 'daylight_studio', label: 'Daylight' },
  { id: 'cyberpunk_night', label: 'Cyberpunk' },
  { id: 'minimalist_warehouse', label: 'Warehouse' },
];

const POSE_OPTIONS: Array<{ id: BotAnimationState; label: string }> = [
  { id: 'scanning_hologram', label: 'Scan' },
  { id: 'celebrating', label: 'Celebrate' },
  { id: 'warning_alert', label: 'Alert' },
  { id: 'repairing_code', label: 'Repair' },
];

const CAMERA_OPTIONS: Array<{ id: CameraPreset; label: string }> = [
  { id: 'desk', label: 'Desk' },
  { id: 'portrait', label: 'Portrait' },
  { id: 'stockroom', label: 'Stockroom' },
];

export const BottomControlDock: React.FC<BottomControlDockProps> = ({
  collapsed,
  onToggleCollapse,
  officeTheme,
  onChangeTheme,
  animationState,
  onChangeAnimation,
  cameraPreset,
  onChangeCamera,
  voiceStatus,
  onToggleVoice,
  drawerOpen,
  wideDrawer = false,
  onToggleDrawer,
}) => {
  const isVoiceActive =
    voiceStatus === 'connected' || voiceStatus === 'connecting';

  return (
    <div
      className={`pointer-events-none fixed bottom-4 left-0 z-20 flex flex-col items-center px-3 transition-all duration-200 ${
        drawerOpen
          ? wideDrawer
            ? 'right-0 xl:right-[920px]'
            : 'right-0 md:right-[560px]'
          : 'right-0'
      }`}
    >
      <button
        type="button"
        onClick={onToggleCollapse}
        aria-expanded={!collapsed}
        className="pointer-events-auto mb-1.5 flex cursor-pointer items-center gap-1.5 rounded-t-lg border border-slate-700/80 bg-slate-900/95 px-3 py-1 text-xs font-medium text-slate-200 transition-colors hover:bg-slate-800 focus-visible:outline-2 focus-visible:outline-blue-500"
      >
        {collapsed ? (
          <>
            <ChevronUp className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Show Controls</span>
          </>
        ) : (
          <>
            <ChevronDown className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Hide Controls</span>
          </>
        )}
      </button>

      {!collapsed && (
        <div
          role="toolbar"
          aria-label="3D Office Controls"
          className="pointer-events-auto flex max-w-full flex-wrap items-center justify-center gap-2 rounded-xl border border-slate-700/90 bg-slate-950/95 px-2.5 py-1.5 text-slate-100 shadow-lg"
        >
          {/* Office Theme Segmented Control */}
          <div className="flex items-center gap-0.5 rounded-lg bg-slate-900 p-0.5">
            {THEME_OPTIONS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => onChangeTheme(t.id)}
                className={`whitespace-nowrap shrink-0 cursor-pointer rounded-md px-2 py-1 text-[11px] font-medium transition-colors ${
                  officeTheme === t.id
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* 3D Animation Pose */}
          <div className="hidden items-center gap-0.5 rounded-lg bg-slate-900 p-0.5 sm:flex">
            {POSE_OPTIONS.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => onChangeAnimation(p.id)}
                className={`whitespace-nowrap shrink-0 cursor-pointer rounded-md px-2 py-1 text-[11px] font-medium transition-colors ${
                  animationState === p.id
                    ? 'bg-slate-700 text-white'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Camera Presets */}
          <div className="flex items-center gap-0.5 rounded-lg bg-slate-900 p-0.5">
            <Camera
              className="mx-1 h-3.5 w-3.5 text-slate-400"
              aria-hidden="true"
            />
            {CAMERA_OPTIONS.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => onChangeCamera(c.id)}
                className={`whitespace-nowrap shrink-0 cursor-pointer rounded-md px-2 py-1 text-[11px] font-medium transition-colors ${
                  cameraPreset === c.id
                    ? 'bg-slate-700 text-white'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>

          {/* Live Voice & Studio Drawer Actions */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onToggleVoice}
              className={`whitespace-nowrap shrink-0 flex cursor-pointer items-center gap-1.5 rounded-lg px-2.5 py-1 text-[11px] font-semibold transition-colors ${
                isVoiceActive
                  ? 'bg-rose-600 text-white hover:bg-rose-500'
                  : 'bg-emerald-600 text-white hover:bg-emerald-500'
              }`}
            >
              {isVoiceActive ? (
                <>
                  <MicOff className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>
                    {voiceStatus === 'connecting' ? 'Connecting...' : 'End Voice'}
                  </span>
                </>
              ) : (
                <>
                  <Mic className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Live Voice</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onToggleDrawer}
              className="whitespace-nowrap shrink-0 flex cursor-pointer items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1 text-[11px] font-semibold text-white transition-colors hover:bg-slate-700"
            >
              {drawerOpen ? (
                <>
                  <PanelRightClose className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Hide Studio</span>
                </>
              ) : (
                <>
                  <PanelRightOpen className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Open Studio</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
