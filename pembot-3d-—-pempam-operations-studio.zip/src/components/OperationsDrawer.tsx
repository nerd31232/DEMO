import React from 'react';
import { X } from 'lucide-react';
import { StudioTab } from './TopBar';

interface OperationsDrawerProps {
  open: boolean;
  activeTab: StudioTab;
  onSelectTab: (tab: StudioTab) => void;
  onClose: () => void;
  children: React.ReactNode;
}

const TABS: Array<{ id: StudioTab; label: string }> = [
  { id: 'operations', label: 'Operations' },
  { id: 'inventory', label: 'Inventory' },
  { id: 'systems', label: 'Pempam Apps' },
  { id: 'calendar', label: 'Calendar' },
  { id: 'customize', label: 'Customize' },
];

export const OperationsDrawer: React.FC<OperationsDrawerProps> = ({
  open,
  activeTab,
  onSelectTab,
  onClose,
  children,
}) => {
  if (!open) return null;

  const isWideAppsView = activeTab === 'systems';

  return (
    <aside
      aria-label="Operations Studio Panel"
      className={`pointer-events-auto fixed top-14 right-0 bottom-0 flex w-full flex-col border-l border-slate-200 bg-white/98 text-slate-900 shadow-2xl transition-all duration-200 ${
        isWideAppsView
          ? 'z-30 max-w-[920px]'
          : 'z-30 max-w-[560px] md:z-10'
      }`}
    >
      <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5">
        <div role="tablist" className="flex items-center gap-1 overflow-x-auto">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              role="tab"
              aria-selected={activeTab === tab.id}
              type="button"
              onClick={() => onSelectTab(tab.id)}
              className={`whitespace-nowrap shrink-0 cursor-pointer rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${
                activeTab === tab.id
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={onClose}
          aria-label="Close Studio Panel"
          className="cursor-pointer rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
        >
          <X className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-5 pb-8">{children}</div>
    </aside>
  );
};
