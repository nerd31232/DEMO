import React from 'react';
import { PendingCalendarAction } from '../types/operations';

interface ConfirmScheduleModalProps {
  pending: PendingCalendarAction | null;
  busy: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmScheduleModal: React.FC<ConfirmScheduleModalProps> = ({
  pending,
  busy,
  onConfirm,
  onCancel,
}) => {
  if (!pending) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-cal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4"
    >
      <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-6 text-slate-900 shadow-2xl">
        <h3 id="confirm-cal-title" className="font-display text-lg font-bold">
          Confirm Google Calendar Event
        </h3>
        <p className="mt-1.5 text-sm text-slate-600">
          Review the event details below before writing to your primary Google
          Calendar (Asia/Manila).
        </p>

        <dl className="mt-4 space-y-2 border-y border-slate-200 py-3 text-sm">
          <div className="flex justify-between gap-4">
            <dt className="font-medium text-slate-500">Title</dt>
            <dd className="text-right font-semibold text-slate-900">
              {pending.summary}
            </dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="font-medium text-slate-500">Start</dt>
            <dd className="font-mono-tabular text-right text-slate-800">
              {new Date(pending.startIso).toLocaleString('en-PH', {
                timeZone: 'Asia/Manila',
              })}
            </dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="font-medium text-slate-500">Location</dt>
            <dd className="text-right text-slate-800">{pending.location}</dd>
          </div>
          <div>
            <dt className="font-medium text-slate-500">Notes</dt>
            <dd className="mt-0.5 text-xs text-slate-700">
              {pending.description}
            </dd>
          </div>
        </dl>

        <div className="mt-5 flex justify-end gap-2.5">
          <button
            type="button"
            onClick={onCancel}
            disabled={busy}
            className="cursor-pointer rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-60"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={busy}
            className="cursor-pointer rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-60"
          >
            {busy ? 'Scheduling...' : 'Confirm & Create Event'}
          </button>
        </div>
      </div>
    </div>
  );
};
